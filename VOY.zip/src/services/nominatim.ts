import type { LocationPoint } from '@/domain/types';
import { isValidLatitude, isValidLongitude } from '@/domain/validation';

/*
 * Cliente de geocodificación con Nominatim (OpenStreetMap, sin API key).
 * Política de uso: máximo ~1 petición/segundo, identificación mediante el
 * Referer del navegador y uso moderado. El control de frecuencia vive en
 * el hook `usePlaceSearch` (debounce + intervalo mínimo).
 * Equivalente Kotlin: Retrofit + kotlinx.serialization.
 */

export interface PlaceResult {
  id: string;
  label: string;
  point: LocationPoint;
  type: string;
}

export class NominatimError extends Error {
  readonly status: number | null;

  constructor(message: string, status: number | null = null) {
    super(message);
    this.name = 'NominatimError';
    this.status = status;
  }
}

const ENDPOINT = 'https://nominatim.openstreetmap.org/search';
const REQUEST_TIMEOUT_MS = 12_000;

function parsePlace(item: unknown): PlaceResult | null {
  if (typeof item !== 'object' || item === null) return null;
  const record = item as Record<string, unknown>;
  const latitude = Number(record.lat);
  const longitude = Number(record.lon);
  if (!isValidLatitude(latitude) || !isValidLongitude(longitude)) return null;
  return {
    id: String(record.place_id ?? `${latitude},${longitude}`),
    label: typeof record.display_name === 'string' ? record.display_name : 'Lugar sin nombre',
    type: typeof record.type === 'string' ? record.type : 'lugar',
    point: { latitude, longitude },
  };
}

export async function searchPlaces(query: string, signal: AbortSignal): Promise<PlaceResult[]> {
  const params = new URLSearchParams({
    q: query,
    format: 'jsonv2',
    limit: '6',
    'accept-language': 'es',
  });

  // Combina la cancelación externa con un timeout propio.
  const controller = new AbortController();
  const onExternalAbort = () => controller.abort();
  signal.addEventListener('abort', onExternalAbort);
  const timer = window.setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

  let response: Response;
  try {
    response = await fetch(`${ENDPOINT}?${params.toString()}`, {
      signal: controller.signal,
      headers: { Accept: 'application/json' },
    });
  } catch (err) {
    if (signal.aborted) throw err;
    if (controller.signal.aborted) {
      throw new NominatimError('La búsqueda tardó demasiado. Inténtalo de nuevo.');
    }
    throw new NominatimError('Sin conexión con el servicio de búsqueda.');
  } finally {
    window.clearTimeout(timer);
    signal.removeEventListener('abort', onExternalAbort);
  }

  if (response.status === 429) {
    throw new NominatimError('Demasiadas búsquedas seguidas. Espera unos segundos.', 429);
  }
  if (!response.ok) {
    throw new NominatimError(`El servicio de búsqueda respondió con error ${response.status}.`, response.status);
  }

  let data: unknown;
  try {
    data = await response.json();
  } catch {
    throw new NominatimError('Respuesta no válida del servicio de búsqueda.');
  }
  if (!Array.isArray(data)) {
    throw new NominatimError('Respuesta no válida del servicio de búsqueda.');
  }
  return data.map(parsePlace).filter((place): place is PlaceResult => place !== null);
}
