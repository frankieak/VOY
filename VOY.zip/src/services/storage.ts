import type {
  AppSettings,
  FavoritesData,
  HistoryEntry,
  LocationPoint,
  SavedPoint,
  SimulatedRoute,
  SimulationMode,
  SpeedUnit,
} from '@/domain/types';
import {
  ACCURACY_RANGE_M,
  INTERVAL_RANGE_MS,
  isValidLatitude,
  isValidLongitude,
} from '@/domain/validation';

/*
 * REPOSITORIOS DE PERSISTENCIA (localStorage en web).
 * Equivalente Kotlin: DataStore<Preferences> para AppSettings y
 * Room (@Entity / @Dao) para favoritos e historial. Cada `load` tolera datos
 * corruptos devolviendo valores por defecto: nunca lanza excepciones.
 */

export const STORAGE_KEYS = {
  settings: 'voy.settings.v1',
  favorites: 'voy.favorites.v1',
  history: 'voy.history.v1',
} as const;

export const HISTORY_LIMIT = 30;

export const DEFAULT_SETTINGS: AppSettings = {
  speedUnit: 'KMH',
  updateIntervalMs: 1000,
  accuracyMeters: 5,
};

export const EMPTY_FAVORITES: FavoritesData = { points: [], routes: [] };

type UnknownRecord = Record<string, unknown>;

const isRecord = (value: unknown): value is UnknownRecord =>
  typeof value === 'object' && value !== null && !Array.isArray(value);

function readJson(key: string): unknown {
  try {
    const raw = window.localStorage.getItem(key);
    return raw === null ? undefined : JSON.parse(raw);
  } catch {
    return undefined;
  }
}

function writeJson(key: string, value: unknown): void {
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // Cuota llena o modo privado: la app sigue funcionando sin persistir.
  }
}

function compact<T>(items: (T | null)[]): T[] {
  return items.filter((item): item is T => item !== null);
}

function toPoint(value: unknown): LocationPoint | null {
  if (!isRecord(value)) return null;
  const latitude = value.latitude;
  const longitude = value.longitude;
  if (typeof latitude !== 'number' || typeof longitude !== 'number') return null;
  if (!isValidLatitude(latitude) || !isValidLongitude(longitude)) return null;
  return { latitude, longitude };
}

function toPoints(value: unknown): LocationPoint[] {
  return Array.isArray(value) ? compact(value.map(toPoint)) : [];
}

function toSavedPoint(value: unknown): SavedPoint | null {
  if (!isRecord(value)) return null;
  const point = toPoint(value.point);
  if (!point || typeof value.id !== 'string') return null;
  return {
    id: value.id,
    name: typeof value.name === 'string' ? value.name : 'Sin nombre',
    point,
    pinned: value.pinned === true,
    createdAt: typeof value.createdAt === 'number' ? value.createdAt : Date.now(),
  };
}

function toRoute(value: unknown): SimulatedRoute | null {
  if (!isRecord(value) || typeof value.id !== 'string') return null;
  const waypoints = toPoints(value.waypoints);
  if (waypoints.length < 2) return null;
  return {
    id: value.id,
    name: typeof value.name === 'string' ? value.name : 'Ruta sin nombre',
    waypoints,
    pinned: value.pinned === true,
    createdAt: typeof value.createdAt === 'number' ? value.createdAt : Date.now(),
  };
}

function toHistoryEntry(value: unknown): HistoryEntry | null {
  if (!isRecord(value) || typeof value.id !== 'string') return null;
  const point = toPoint(value.point);
  if (!point) return null;
  const mode: SimulationMode = value.mode === 'ROUTE' ? 'ROUTE' : 'POINT';
  return {
    id: value.id,
    point,
    mode,
    label: typeof value.label === 'string' ? value.label : 'Ubicación',
    timestampMs: typeof value.timestampMs === 'number' ? value.timestampMs : Date.now(),
  };
}

function sanitizeSettings(value: unknown): AppSettings {
  if (!isRecord(value)) return { ...DEFAULT_SETTINGS };
  const unit: SpeedUnit = value.speedUnit === 'MS' ? 'MS' : 'KMH';
  const interval = value.updateIntervalMs;
  const accuracy = value.accuracyMeters;
  return {
    speedUnit: unit,
    updateIntervalMs:
      typeof interval === 'number' &&
      interval >= INTERVAL_RANGE_MS.min &&
      interval <= INTERVAL_RANGE_MS.max
        ? Math.round(interval)
        : DEFAULT_SETTINGS.updateIntervalMs,
    accuracyMeters:
      typeof accuracy === 'number' && accuracy >= ACCURACY_RANGE_M.min && accuracy <= ACCURACY_RANGE_M.max
        ? accuracy
        : DEFAULT_SETTINGS.accuracyMeters,
  };
}

export const settingsStore = {
  load(): AppSettings {
    return sanitizeSettings(readJson(STORAGE_KEYS.settings));
  },
  save(settings: AppSettings): void {
    writeJson(STORAGE_KEYS.settings, settings);
  },
};

export const favoritesStore = {
  load(): FavoritesData {
    const raw = readJson(STORAGE_KEYS.favorites);
    if (!isRecord(raw)) return { ...EMPTY_FAVORITES };
    return {
      points: Array.isArray(raw.points) ? compact(raw.points.map(toSavedPoint)) : [],
      routes: Array.isArray(raw.routes) ? compact(raw.routes.map(toRoute)) : [],
    };
  },
  save(data: FavoritesData): void {
    writeJson(STORAGE_KEYS.favorites, data);
  },
};

export const historyStore = {
  load(): HistoryEntry[] {
    const raw = readJson(STORAGE_KEYS.history);
    return Array.isArray(raw) ? compact(raw.map(toHistoryEntry)).slice(0, HISTORY_LIMIT) : [];
  },
  save(entries: HistoryEntry[]): void {
    writeJson(STORAGE_KEYS.history, entries);
  },
};
