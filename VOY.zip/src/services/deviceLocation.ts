import type { LocationPoint } from '@/domain/types';

/*
 * Ubicación real del dispositivo (navegador). Se usa solo para centrar el mapa.
 * Equivalente Kotlin: FusedLocationProviderClient.getCurrentLocation(...).
 */

const ERROR_MESSAGES: Record<number, string> = {
  1: 'Permiso de ubicación denegado. Actívalo en la configuración del navegador.',
  2: 'Tu ubicación no está disponible en este momento.',
  3: 'Se agotó el tiempo para obtener tu ubicación.',
};

export function getDeviceLocation(): Promise<LocationPoint> {
  return new Promise((resolve, reject) => {
    if (typeof navigator === 'undefined' || !('geolocation' in navigator)) {
      reject(new Error('Este navegador no soporta geolocalización.'));
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (position) =>
        resolve({ latitude: position.coords.latitude, longitude: position.coords.longitude }),
      (error) => reject(new Error(ERROR_MESSAGES[error.code] ?? 'No se pudo obtener tu ubicación.')),
      { enableHighAccuracy: true, timeout: 12_000, maximumAge: 30_000 },
    );
  });
}
