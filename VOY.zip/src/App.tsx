import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { AndroidNotification } from '@/components/AndroidNotification';
import { ControlSheet } from '@/components/ControlSheet';
import { LibraryDrawer, type LibraryTab } from '@/components/LibraryDrawer';
import { MapControls } from '@/components/MapControls';
import { MapView, type MapHandle } from '@/components/MapView';
import { SettingsModal } from '@/components/SettingsModal';
import { TopPanel } from '@/components/TopPanel';
import { Toast, type ToastMessage } from '@/components/ui';
import { useFavorites } from '@/hooks/useFavorites';
import { useHistory } from '@/hooks/useHistory';
import { usePlaceSearch } from '@/hooks/usePlaceSearch';
import { useSettings } from '@/hooks/useSettings';
import { useSimulation } from '@/hooks/useSimulation';
import type {
  HistoryEntry,
  LocationPoint,
  SavedPoint,
  SimulatedRoute,
  SimulationConfig,
  SimulationMode,
} from '@/domain/types';
import { getDeviceLocation } from '@/services/deviceLocation';
import type { PlaceResult } from '@/services/nominatim';
import { cn } from '@/utils/cn';

/*
 * COMPOSICIÓN DE LA APP.
 * Este componente solo conecta hooks (dominio/estado) con componentes (UI).
 * Equivalente Kotlin: un Screen composable que observa el ViewModel
 * y delega cada acción en un método del ViewModel.
 */

const DEFAULT_POINT: LocationPoint = { latitude: 40.4168, longitude: -3.7038 };
const DEFAULT_SPEED_KMH = 5;
const TOAST_DURATION_MS = 3200;

export default function App() {
  const { settings, update: updateSettings, reset: resetSettings } = useSettings();
  const favorites = useFavorites();
  const history = useHistory();
  const search = usePlaceSearch();

  const [mode, setMode] = useState<SimulationMode>('POINT');
  const [fixedPoint, setFixedPoint] = useState<LocationPoint | null>(DEFAULT_POINT);
  const [waypoints, setWaypoints] = useState<LocationPoint[]>([]);
  const [speedKmh, setSpeedKmh] = useState(DEFAULT_SPEED_KMH);
  const [loop, setLoop] = useState(false);
  const [follow, setFollow] = useState(true);
  const [collapsed, setCollapsed] = useState(false);
  const [locating, setLocating] = useState(false);
  const [libraryOpen, setLibraryOpen] = useState(false);
  const [libraryTab, setLibraryTab] = useState<LibraryTab>('FAVORITES');
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [toast, setToast] = useState<ToastMessage | null>(null);
  const mapRef = useRef<MapHandle>(null);

  const simConfig = useMemo<SimulationConfig>(
    () => ({
      mode,
      fixedPoint,
      waypoints,
      speedKmh,
      loop,
      accuracyMeters: settings.accuracyMeters,
      updateIntervalMs: settings.updateIntervalMs,
    }),
    [mode, fixedPoint, waypoints, speedKmh, loop, settings.accuracyMeters, settings.updateIntervalMs],
  );

  const sim = useSimulation(simConfig);
  const { state, start, pause, resume, stop } = sim;
  const isActive = state.status === 'RUNNING' || state.status === 'PAUSED';

  const notify = useCallback((message: string, tone: ToastMessage['tone'] = 'info') => {
    setToast({ id: Date.now(), message, tone });
  }, []);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(null), TOAST_DURATION_MS);
    return () => window.clearTimeout(timer);
  }, [toast]);

  /* ---------- Cambios de modo y edición de ruta (detienen la simulación activa) ---------- */

  const changeMode = (next: SimulationMode) => {
    if (next === mode) return;
    if (isActive) {
      stop();
      notify('Simulación detenida al cambiar de modo.');
    }
    setMode(next);
  };

  const changeWaypoints = (next: LocationPoint[]) => {
    if (isActive) {
      stop();
      notify('Simulación detenida: la ruta fue modificada.');
    }
    setWaypoints(next);
  };

  /* ---------- Interacción con el mapa ---------- */

  const handleMapClick = (point: LocationPoint) => {
    if (mode === 'POINT') setFixedPoint(point);
    else changeWaypoints([...waypoints, point]);
  };

  const handleFixedPointChange = (point: LocationPoint) => setFixedPoint(point);

  const handleWaypointMove = (index: number, point: LocationPoint) =>
    changeWaypoints(waypoints.map((wp, i) => (i === index ? point : wp)));

  const handleWaypointRemove = (index: number) => changeWaypoints(waypoints.filter((_, i) => i !== index));

  const handleUndoWaypoint = () => changeWaypoints(waypoints.slice(0, -1));

  const handleClearRoute = () => changeWaypoints([]);

  /** Añade un destino desde buscador o coordenadas: punto fijo o nuevo waypoint según el modo. */
  const addTarget = (point: LocationPoint) => {
    if (mode === 'POINT') setFixedPoint(point);
    else changeWaypoints([...waypoints, point]);
    mapRef.current?.flyTo(point);
  };

  const handlePickPlace = (place: PlaceResult) => {
    search.clear();
    addTarget(place.point);
    notify(
      mode === 'POINT' ? `Punto fijado: ${place.label.split(',')[0]}` : 'Lugar añadido a la ruta',
      'success',
    );
  };

  const handleSubmitCoordinates = (point: LocationPoint) => {
    addTarget(point);
    notify(mode === 'POINT' ? 'Coordenadas aplicadas.' : 'Coordenada añadida a la ruta.', 'success');
  };

  /* ---------- Controles de simulación ---------- */

  const handleStart = () => {
    const error = start();
    if (error) {
      notify(error, 'error');
      return;
    }
    const startPoint = mode === 'POINT' ? fixedPoint : waypoints[0];
    if (startPoint) {
      history.record(startPoint, mode, mode === 'POINT' ? 'Punto fijo' : `Ruta · ${waypoints.length} puntos`);
    }
    setFollow(true);
    notify(mode === 'POINT' ? 'Simulación de punto fijo iniciada.' : 'Simulación de ruta iniciada.', 'success');
  };

  const handlePause = () => {
    pause();
    notify('Simulación en pausa.');
  };

  const handleResume = () => {
    resume();
    notify('Simulación reanudada.');
  };

  const handleStop = () => {
    stop();
    notify('Simulación detenida.');
  };

  const handleSavePoint = (name: string) => {
    if (!fixedPoint) return;
    favorites.savePoint(name, fixedPoint);
    notify('Punto guardado en favoritos.', 'success');
  };

  const handleSaveRoute = (name: string) => {
    if (waypoints.length < 2) return;
    favorites.saveRoute(name, waypoints);
    notify('Ruta guardada en favoritos.', 'success');
  };

  /* ---------- Ubicación del dispositivo y cámara ---------- */

  const handleLocate = async () => {
    setLocating(true);
    try {
      const point = await getDeviceLocation();
      mapRef.current?.flyTo(point, 16);
      setFollow(false);
      notify('Mapa centrado en tu ubicación.', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'No se pudo obtener tu ubicación.', 'error');
    } finally {
      setLocating(false);
    }
  };

  const handleCenterSimulation = () => {
    if (!state.currentFix) {
      notify('No hay posición simulada activa.', 'error');
      return;
    }
    mapRef.current?.flyTo(state.currentFix);
    setFollow(true);
  };

  /* ---------- Biblioteca (favoritos e historial) ---------- */

  const handleLoadPoint = (item: SavedPoint) => {
    if (isActive) stop();
    setMode('POINT');
    setFixedPoint(item.point);
    setLibraryOpen(false);
    mapRef.current?.flyTo(item.point);
  };

  const handleLoadRoute = (route: SimulatedRoute) => {
    if (isActive) stop();
    setMode('ROUTE');
    setWaypoints(route.waypoints);
    setLibraryOpen(false);
    mapRef.current?.fitTo(route.waypoints);
  };

  const handleLoadHistory = (entry: HistoryEntry) => {
    setLibraryOpen(false);
    addTarget(entry.point);
    notify('Ubicación del historial cargada.', 'success');
  };

  const handleResetAll = () => {
    stop();
    resetSettings();
    favorites.reset();
    history.clear();
    setMode('POINT');
    setFixedPoint(DEFAULT_POINT);
    setWaypoints([]);
    setSpeedKmh(DEFAULT_SPEED_KMH);
    setLoop(false);
    notify('Datos locales borrados.', 'success');
  };

  const openLibrary = (tab: LibraryTab) => {
    setLibraryTab(tab);
    setLibraryOpen(true);
  };

  const isPaused = state.status === 'PAUSED';

  return (
    <div className="relative h-dvh w-full overflow-hidden bg-zinc-950 text-zinc-100">
      <MapView
        ref={mapRef}
        mode={mode}
        fixedPoint={fixedPoint}
        waypoints={waypoints}
        fix={state.currentFix}
        accuracyMeters={settings.accuracyMeters}
        follow={follow}
        onMapClick={handleMapClick}
        onFixedPointChange={handleFixedPointChange}
        onWaypointChange={handleWaypointMove}
        onUserPan={() => setFollow(false)}
      />

      {/* Columna superior: marca, buscador, notificación y avisos */}
      <div className="pointer-events-none absolute inset-x-0 top-0 z-[500] flex flex-col gap-2 p-3 md:right-auto md:w-[440px]">
        <TopPanel
          mode={mode}
          fixedPoint={fixedPoint}
          search={search}
          onPickPlace={handlePickPlace}
          onSubmitCoordinates={handleSubmitCoordinates}
          onOpenLibrary={() => openLibrary('FAVORITES')}
          onOpenHistory={() => openLibrary('HISTORY')}
          onOpenSettings={() => setSettingsOpen(true)}
        />
        <AndroidNotification
          visible={isActive}
          paused={isPaused}
          fix={state.currentFix}
          speedUnit={settings.speedUnit}
          onStop={handleStop}
        />
        <Toast toast={toast} />
      </div>

      <MapControls
        className={cn(
          'pointer-events-auto absolute right-3 z-[500] transition-[bottom] duration-300',
          collapsed ? 'bottom-[11rem]' : 'bottom-[calc(44dvh+10.5rem)]',
          'md:bottom-6 md:right-4',
        )}
        follow={follow}
        hasFix={state.currentFix !== null}
        locating={locating}
        onToggleFollow={() => setFollow((value) => !value)}
        onZoomIn={() => mapRef.current?.zoomIn()}
        onZoomOut={() => mapRef.current?.zoomOut()}
        onLocate={handleLocate}
        onCenterSimulation={handleCenterSimulation}
      />

      {/* Panel de control: hoja inferior en móvil, columna lateral en escritorio */}
      <ControlSheet
        className="absolute inset-x-0 bottom-0 z-[500] md:inset-x-auto md:bottom-3 md:left-3 md:w-[440px]"
        collapsed={collapsed}
        onToggleCollapsed={() => setCollapsed((value) => !value)}
        mode={mode}
        onModeChange={changeMode}
        fixedPoint={fixedPoint}
        onSavePoint={handleSavePoint}
        waypoints={waypoints}
        onWaypointRemove={handleWaypointRemove}
        onUndoWaypoint={handleUndoWaypoint}
        onClearRoute={handleClearRoute}
        onSaveRoute={handleSaveRoute}
        speedKmh={speedKmh}
        onSpeedChange={setSpeedKmh}
        loop={loop}
        onLoopChange={setLoop}
        accuracyMeters={settings.accuracyMeters}
        onAccuracyChange={(meters) => updateSettings({ accuracyMeters: meters })}
        speedUnit={settings.speedUnit}
        state={state}
        onStart={handleStart}
        onPause={handlePause}
        onResume={handleResume}
        onStop={handleStop}
      />

      <LibraryDrawer
        open={libraryOpen}
        onClose={() => setLibraryOpen(false)}
        tab={libraryTab}
        onTabChange={setLibraryTab}
        points={favorites.points}
        routes={favorites.routes}
        history={history.entries}
        onLoadPoint={handleLoadPoint}
        onLoadRoute={handleLoadRoute}
        onTogglePin={favorites.togglePin}
        onRemove={favorites.remove}
        onLoadHistory={handleLoadHistory}
        onClearHistory={history.clear}
      />

      <SettingsModal
        open={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        settings={settings}
        onChange={updateSettings}
        onResetAll={handleResetAll}
      />
    </div>
  );
}
