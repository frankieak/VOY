import { useCallback } from 'react';
import type { HistoryEntry, LocationPoint, SimulationMode } from '@/domain/types';
import { HISTORY_LIMIT, historyStore } from '@/services/storage';
import { createId } from '@/utils/id';
import { usePersistentState } from './usePersistentState';

export function useHistory() {
  const [entries, setEntries] = usePersistentState<HistoryEntry[]>(historyStore.load, historyStore.save);

  const record = useCallback(
    (point: LocationPoint, mode: SimulationMode, label: string) => {
      const entry: HistoryEntry = {
        id: createId('hs'),
        point: { latitude: point.latitude, longitude: point.longitude },
        mode,
        label,
        timestampMs: Date.now(),
      };
      setEntries((prev) => [entry, ...prev].slice(0, HISTORY_LIMIT));
    },
    [setEntries],
  );

  const clear = useCallback(() => setEntries([]), [setEntries]);

  return { entries, record, clear };
}
