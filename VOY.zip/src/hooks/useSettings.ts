import { useCallback } from 'react';
import type { AppSettings } from '@/domain/types';
import { DEFAULT_SETTINGS, settingsStore } from '@/services/storage';
import { usePersistentState } from './usePersistentState';

export function useSettings() {
  const [settings, setSettings] = usePersistentState<AppSettings>(settingsStore.load, settingsStore.save);

  const update = useCallback(
    (patch: Partial<AppSettings>) => setSettings((prev) => ({ ...prev, ...patch })),
    [setSettings],
  );

  const reset = useCallback(() => setSettings({ ...DEFAULT_SETTINGS }), [setSettings]);

  return { settings, update, reset };
}
