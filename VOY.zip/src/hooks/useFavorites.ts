import { useCallback, useMemo } from 'react';
import type { FavoriteKind, FavoritesData, LocationPoint, SavedPoint, SimulatedRoute } from '@/domain/types';
import { favoritesStore } from '@/services/storage';
import { createId } from '@/utils/id';
import { usePersistentState } from './usePersistentState';

const MAX_NAME_LENGTH = 60;

const cleanName = (name: string, fallback: string): string =>
  name.trim().slice(0, MAX_NAME_LENGTH) || fallback;

/** Fijados primero, después los más recientes. */
function byPriority<T extends { pinned: boolean; createdAt: number }>(items: T[]): T[] {
  return [...items].sort((a, b) => Number(b.pinned) - Number(a.pinned) || b.createdAt - a.createdAt);
}

export function useFavorites() {
  const [data, setData] = usePersistentState<FavoritesData>(favoritesStore.load, favoritesStore.save);

  const savePoint = useCallback(
    (name: string, point: LocationPoint) => {
      const item: SavedPoint = {
        id: createId('pt'),
        name: cleanName(name, 'Punto sin nombre'),
        point: { latitude: point.latitude, longitude: point.longitude },
        pinned: false,
        createdAt: Date.now(),
      };
      setData((prev) => ({ ...prev, points: [item, ...prev.points] }));
    },
    [setData],
  );

  const saveRoute = useCallback(
    (name: string, waypoints: LocationPoint[]) => {
      const item: SimulatedRoute = {
        id: createId('rt'),
        name: cleanName(name, 'Ruta sin nombre'),
        waypoints: waypoints.map((w) => ({ latitude: w.latitude, longitude: w.longitude })),
        pinned: false,
        createdAt: Date.now(),
      };
      setData((prev) => ({ ...prev, routes: [item, ...prev.routes] }));
    },
    [setData],
  );

  const togglePin = useCallback(
    (kind: FavoriteKind, id: string) =>
      setData((prev) =>
        kind === 'POINT'
          ? { ...prev, points: prev.points.map((p) => (p.id === id ? { ...p, pinned: !p.pinned } : p)) }
          : { ...prev, routes: prev.routes.map((r) => (r.id === id ? { ...r, pinned: !r.pinned } : r)) },
      ),
    [setData],
  );

  const remove = useCallback(
    (kind: FavoriteKind, id: string) =>
      setData((prev) =>
        kind === 'POINT'
          ? { ...prev, points: prev.points.filter((p) => p.id !== id) }
          : { ...prev, routes: prev.routes.filter((r) => r.id !== id) },
      ),
    [setData],
  );

  const reset = useCallback(() => setData({ points: [], routes: [] }), [setData]);

  const points = useMemo(() => byPriority(data.points), [data.points]);
  const routes = useMemo(() => byPriority(data.routes), [data.routes]);

  return { points, routes, savePoint, saveRoute, togglePin, remove, reset };
}
