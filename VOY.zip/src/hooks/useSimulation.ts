import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { advanceSimulation, validateForStart } from '@/domain/simulationEngine';
import { buildRouteIndex } from '@/domain/route';
import type { SimulationConfig, SimulationMode, SimulationState } from '@/domain/types';

/*
 * HOOK DE SIMULACIÓN — único lugar con timers (setInterval).
 * Ciclo de vida del timer:
 *   - Se crea solo cuando status === 'RUNNING'.
 *   - Se destruye en pausa, parada, completado, cambio de intervalo o desmontaje.
 * Equivalente Kotlin: un Job de coroutine `while (isActive) { delay(interval); step() }`
 * cancelado en pause/stop, dentro del ViewModel o del ForegroundService.
 */

export interface SimulationController {
  readonly state: SimulationState;
  /** Inicia desde cero. Devuelve un mensaje de error o null si arrancó. */
  start: () => string | null;
  pause: () => void;
  resume: () => void;
  stop: () => void;
}

const idleState = (mode: SimulationMode): SimulationState => ({
  status: 'IDLE',
  mode,
  currentFix: null,
  traveledMeters: 0,
  totalMeters: 0,
  lap: 0,
  startedAtMs: null,
});

export function useSimulation(config: SimulationConfig): SimulationController {
  const [state, setState] = useState<SimulationState>(() => idleState(config.mode));

  // Refs: el timer siempre lee la configuración más reciente sin reiniciarse.
  const configRef = useRef(config);
  const travelRef = useRef(0);
  const lapRef = useRef(0);
  const lastTickRef = useRef(0);

  const status = state.status;
  const updateIntervalMs = config.updateIntervalMs;

  useEffect(() => {
    configRef.current = config;
  }, [config]);

  const applyStep = useCallback((elapsedSeconds: number) => {
    const cfg = configRef.current;
    const out = advanceSimulation({
      config: cfg,
      previousTraveledMeters: travelRef.current,
      previousLap: lapRef.current,
      elapsedSeconds,
      nowMs: Date.now(),
    });
    if (!out) return;
    travelRef.current = out.traveledMeters;
    lapRef.current = out.lap;

    setState((prev) => {
      // Protege contra ticks rezagados tras una parada o pausa.
      if (prev.status !== 'RUNNING') return prev;
      return {
        ...prev,
        mode: cfg.mode,
        status: out.completed ? 'COMPLETED' : 'RUNNING',
        currentFix: out.fix,
        traveledMeters: out.traveledMeters,
        totalMeters: out.totalMeters,
        lap: out.lap,
      };
    });
  }, []);

  // Timer: existe solo mientras la simulación está RUNNING.
  useEffect(() => {
    if (status !== 'RUNNING') return;
    lastTickRef.current = performance.now();
    const id = window.setInterval(() => {
      const now = performance.now();
      const elapsedSeconds = (now - lastTickRef.current) / 1000;
      lastTickRef.current = now;
      applyStep(elapsedSeconds);
    }, updateIntervalMs);
    return () => window.clearInterval(id);
  }, [status, updateIntervalMs, applyStep]);

  const start = useCallback((): string | null => {
    const cfg = configRef.current;
    const error = validateForStart(cfg);
    if (error) return error;

    travelRef.current = 0;
    lapRef.current = 0;
    setState({
      status: 'RUNNING',
      mode: cfg.mode,
      currentFix: null,
      traveledMeters: 0,
      totalMeters: buildRouteIndex(cfg.waypoints).totalMeters,
      lap: 0,
      startedAtMs: Date.now(),
    });
    applyStep(0); // primera posición inmediata
    return null;
  }, [applyStep]);

  const pause = useCallback(
    () => setState((prev) => (prev.status === 'RUNNING' ? { ...prev, status: 'PAUSED' } : prev)),
    [],
  );

  const resume = useCallback(
    () => setState((prev) => (prev.status === 'PAUSED' ? { ...prev, status: 'RUNNING' } : prev)),
    [],
  );

  const stop = useCallback(() => {
    travelRef.current = 0;
    lapRef.current = 0;
    setState(idleState(configRef.current.mode));
  }, []);

  return useMemo(() => ({ state, start, pause, resume, stop }), [state, start, pause, resume, stop]);
}
