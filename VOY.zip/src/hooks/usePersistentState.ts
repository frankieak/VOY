import { useEffect, useState, type Dispatch, type SetStateAction } from 'react';

/**
 * Estado sincronizado con un repositorio de persistencia.
 * `load` y `save` deben ser referencias estables (métodos de un store de módulo).
 */
export function usePersistentState<T>(
  load: () => T,
  save: (value: T) => void,
): [T, Dispatch<SetStateAction<T>>] {
  const [value, setValue] = useState<T>(load);

  useEffect(() => {
    save(value);
  }, [value, save]);

  return [value, setValue];
}
