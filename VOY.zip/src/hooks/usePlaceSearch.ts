import { useCallback, useEffect, useRef, useState } from 'react';
import { searchPlaces, type PlaceResult } from '@/services/nominatim';

const MIN_QUERY_LENGTH = 3;
const DEBOUNCE_MS = 600;
/** Respeta la política de uso de Nominatim (≈1 petición por segundo). */
const MIN_REQUEST_GAP_MS = 1100;

/**
 * Búsqueda de lugares con debounce, cancelación de peticiones obsoletas,
 * intervalo mínimo entre llamadas y estados de carga/error.
 */
export function usePlaceSearch() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<PlaceResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const lastRequestRef = useRef(0);

  const updateQuery = useCallback((value: string) => {
    setQuery(value);
    if (value.trim().length < MIN_QUERY_LENGTH) {
      setResults([]);
      setError(null);
      setLoading(false);
      return;
    }
    setError(null);
    setLoading(true);
  }, []);

  useEffect(() => {
    const trimmed = query.trim();
    if (trimmed.length < MIN_QUERY_LENGTH) return;

    const controller = new AbortController();
    const sinceLast = Date.now() - lastRequestRef.current;
    const wait = Math.max(DEBOUNCE_MS, MIN_REQUEST_GAP_MS - sinceLast);

    const timer = window.setTimeout(() => {
      lastRequestRef.current = Date.now();
      searchPlaces(trimmed, controller.signal)
        .then((items) => {
          if (controller.signal.aborted) return;
          setResults(items);
          setError(items.length === 0 ? 'No encontramos resultados para esa búsqueda.' : null);
        })
        .catch((err: unknown) => {
          if (controller.signal.aborted) return;
          setResults([]);
          setError(err instanceof Error ? err.message : 'Error desconocido al buscar.');
        })
        .finally(() => {
          if (!controller.signal.aborted) setLoading(false);
        });
    }, wait);

    return () => {
      window.clearTimeout(timer);
      controller.abort();
    };
  }, [query]);

  const clear = useCallback(() => updateQuery(''), [updateQuery]);

  return { query, updateQuery, results, loading, error, clear };
}

export type PlaceSearch = ReturnType<typeof usePlaceSearch>;
