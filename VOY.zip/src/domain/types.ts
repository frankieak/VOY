/**
 * ============================================================================
 *  VOY — MODELOS DE DOMINIO (fuente de verdad para la migración a Kotlin)
 * ============================================================================
 *
 * Este archivo NO depende de React ni del DOM. Todo lo que aquí se define
 * debe poder traducirse 1:1 a Kotlin (Jetpack Compose + ViewModel +
 * ForegroundService). Equivalencias propuestas:
 *
 * ----------------------------------------------------------------------------
 * // LocationPoint.kt
 * data class LocationPoint(
 *     val latitude: Double,    // -90.0  .. 90.0
 *     val longitude: Double,   // -180.0 .. 180.0
 * )
 *
 * // LocationFix.kt  (equivale a android.location.Location simulada)
 * data class LocationFix(
 *     val latitude: Double,
 *     val longitude: Double,
 *     val accuracyMeters: Float,   // radio de precisión (3..15 m)
 *     val bearingDeg: Float,       // rumbo 0..360 (Location.bearing)
 *     val speedMs: Float,          // m/s (Location.speed)
 *     val timestampMs: Long,       // System.currentTimeMillis()
 * )
 *
 * // SimulatedRoute.kt
 * data class SimulatedRoute(
 *     val id: String,
 *     val name: String,
 *     val waypoints: List<LocationPoint>,
 *     val pinned: Boolean = false,
 *     val createdAt: Long,
 * )
 *
 * // SavedPoint.kt
 * data class SavedPoint(
 *     val id: String,
 *     val name: String,
 *     val point: LocationPoint,
 *     val pinned: Boolean = false,
 *     val createdAt: Long,
 * )
 *
 * // SimulationConfig.kt
 * enum class SimulationMode { POINT, ROUTE }
 * data class SimulationConfig(
 *     val mode: SimulationMode,
 *     val fixedPoint: LocationPoint?,
 *     val waypoints: List<LocationPoint>,
 *     val speedKmh: Double,
 *     val loop: Boolean,
 *     val accuracyMeters: Float,
 *     val updateIntervalMs: Long,
 * )
 *
 * // SimulationState.kt   (StateFlow<SimulationState> en el ViewModel)
 * enum class SimulationStatus { IDLE, RUNNING, PAUSED, COMPLETED }
 * data class SimulationState(
 *     val status: SimulationStatus,
 *     val mode: SimulationMode,
 *     val currentFix: LocationFix?,
 *     val traveledMeters: Double,
 *     val totalMeters: Double,
 *     val lap: Int,
 *     val startedAtMs: Long?,
 * )
 *
 * // HistoryEntry.kt  (Room @Entity en Android)
 * data class HistoryEntry(
 *     val id: String,
 *     val point: LocationPoint,
 *     val mode: SimulationMode,
 *     val label: String,
 *     val timestampMs: Long,
 * )
 *
 * // AppSettings.kt   (DataStore<Preferences> en Android)
 * enum class SpeedUnit { KMH, MS }
 * data class AppSettings(
 *     val speedUnit: SpeedUnit = SpeedUnit.KMH,
 *     val updateIntervalMs: Long = 1000,
 *     val accuracyMeters: Float = 5f,
 * )
 *
 * ----------------------------------------------------------------------------
 * NOTAS DE PORTABILIDAD A ANDROID
 * - Motor de simulación (simulationEngine.ts) -> clase pura en Kotlin
 *   (sin Android imports) testeable con JUnit.
 * - Bucle de tiempo (useSimulation.ts) -> coroutine con `while (isActive) { delay(interval) }`
 *   dentro de un ViewModel, o dentro de un ForegroundService para que siga activo en segundo plano.
 * - Inyección real de ubicación: LocationManager.addTestProvider(...) +
 *   setTestProviderLocation(...) con el permiso ACCESS_MOCK_LOCATION, activado
 *   desde Opciones de desarrollador > "Seleccionar aplicación para ubicación simulada".
 * - Notificación persistente -> NotificationCompat con foregroundServiceType="location".
 * - Almacenamiento: localStorage (web) -> DataStore (ajustes) + Room (favoritos/historial).
 * ============================================================================
 */

export type SimulationMode = 'POINT' | 'ROUTE';
export type SimulationStatus = 'IDLE' | 'RUNNING' | 'PAUSED' | 'COMPLETED';
export type SpeedUnit = 'KMH' | 'MS';
export type FavoriteKind = 'POINT' | 'ROUTE';

export interface LocationPoint {
  readonly latitude: number;
  readonly longitude: number;
}

export interface LocationFix extends LocationPoint {
  readonly accuracyMeters: number;
  readonly bearingDeg: number;
  readonly speedMs: number;
  readonly timestampMs: number;
}

export interface SimulatedRoute {
  id: string;
  name: string;
  waypoints: LocationPoint[];
  pinned: boolean;
  createdAt: number;
}

export interface SavedPoint {
  id: string;
  name: string;
  point: LocationPoint;
  pinned: boolean;
  createdAt: number;
}

export interface FavoritesData {
  points: SavedPoint[];
  routes: SimulatedRoute[];
}

export interface SimulationConfig {
  mode: SimulationMode;
  fixedPoint: LocationPoint | null;
  waypoints: LocationPoint[];
  speedKmh: number;
  loop: boolean;
  accuracyMeters: number;
  updateIntervalMs: number;
}

export interface SimulationState {
  status: SimulationStatus;
  mode: SimulationMode;
  currentFix: LocationFix | null;
  traveledMeters: number;
  totalMeters: number;
  lap: number;
  startedAtMs: number | null;
}

export interface HistoryEntry {
  id: string;
  point: LocationPoint;
  mode: SimulationMode;
  label: string;
  timestampMs: number;
}

export interface AppSettings {
  speedUnit: SpeedUnit;
  updateIntervalMs: number;
  accuracyMeters: number;
}
