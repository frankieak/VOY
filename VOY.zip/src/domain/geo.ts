import type { LocationPoint, SpeedUnit } from './types';

/* Funciones geodésicas puras (esfera). Equivalen a utilidades en Kotlin. */

const EARTH_RADIUS_M = 6_371_008.8;
const DEG_TO_RAD = Math.PI / 180;
const RAD_TO_DEG = 180 / Math.PI;
const CARDINALS = ['N', 'NE', 'E', 'SE', 'S', 'SO', 'O', 'NO'] as const;

export function normalizeBearing(deg: number): number {
  return ((deg % 360) + 360) % 360;
}

export function normalizeLongitude(lon: number): number {
  return ((((lon + 180) % 360) + 360) % 360) - 180;
}

/** Distancia de gran círculo (Haversine) en metros. */
export function haversineMeters(a: LocationPoint, b: LocationPoint): number {
  const dLat = (b.latitude - a.latitude) * DEG_TO_RAD;
  const dLon = (b.longitude - a.longitude) * DEG_TO_RAD;
  const lat1 = a.latitude * DEG_TO_RAD;
  const lat2 = b.latitude * DEG_TO_RAD;
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon / 2) ** 2;
  return 2 * EARTH_RADIUS_M * Math.asin(Math.min(1, Math.sqrt(h)));
}

/** Rumbo inicial (grados 0..360, norte = 0) desde `a` hacia `b`. */
export function bearingBetween(a: LocationPoint, b: LocationPoint): number {
  const lat1 = a.latitude * DEG_TO_RAD;
  const lat2 = b.latitude * DEG_TO_RAD;
  const dLon = (b.longitude - a.longitude) * DEG_TO_RAD;
  const y = Math.sin(dLon) * Math.cos(lat2);
  const x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLon);
  return normalizeBearing(Math.atan2(y, x) * RAD_TO_DEG);
}

/** Punto destino a `distanceM` metros desde `origin` con rumbo `bearingDeg`. */
export function destinationPoint(origin: LocationPoint, distanceM: number, bearingDeg: number): LocationPoint {
  const delta = distanceM / EARTH_RADIUS_M;
  const theta = bearingDeg * DEG_TO_RAD;
  const lat1 = origin.latitude * DEG_TO_RAD;
  const lon1 = origin.longitude * DEG_TO_RAD;
  const lat2 = Math.asin(
    Math.sin(lat1) * Math.cos(delta) + Math.cos(lat1) * Math.sin(delta) * Math.cos(theta),
  );
  const lon2 =
    lon1 +
    Math.atan2(
      Math.sin(theta) * Math.sin(delta) * Math.cos(lat1),
      Math.cos(delta) - Math.sin(lat1) * Math.sin(lat2),
    );
  return { latitude: lat2 * RAD_TO_DEG, longitude: normalizeLongitude(lon2 * RAD_TO_DEG) };
}

/**
 * Interpolación lineal entre dos vértices de un mismo segmento (t en 0..1).
 * Para segmentos de pocos kilómetros el error es despreciable.
 */
export function interpolatePoint(a: LocationPoint, b: LocationPoint, t: number): LocationPoint {
  return {
    latitude: a.latitude + (b.latitude - a.latitude) * t,
    longitude: a.longitude + (b.longitude - a.longitude) * t,
  };
}

/** Desplaza aleatoriamente un punto dentro de un radio: simula el ruido del GPS. */
export function jitterPoint(
  origin: LocationPoint,
  radiusM: number,
  random: () => number = Math.random,
): LocationPoint {
  if (radiusM <= 0) return { latitude: origin.latitude, longitude: origin.longitude };
  return destinationPoint(origin, random() * radiusM, random() * 360);
}

export const kmhToMs = (kmh: number): number => kmh / 3.6;
export const msToKmh = (ms: number): number => ms * 3.6;

export function cardinalDirection(deg: number): string {
  return CARDINALS[Math.round(normalizeBearing(deg) / 45) % 8];
}

/* ---------- Formato (solo presentación) ---------- */

export function formatCoordinate(value: number): string {
  return value.toFixed(6);
}

export function formatSpeed(speedMs: number, unit: SpeedUnit): string {
  return unit === 'KMH' ? `${msToKmh(speedMs).toFixed(1)} km/h` : `${speedMs.toFixed(2)} m/s`;
}

export function formatBearing(deg: number): string {
  return `${Math.round(normalizeBearing(deg))}° ${cardinalDirection(deg)}`;
}

export function formatDistance(meters: number): string {
  return meters < 1000 ? `${Math.round(meters)} m` : `${(meters / 1000).toFixed(2)} km`;
}

export function formatDuration(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds < 0) return '—';
  const total = Math.round(seconds);
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  const pad = (n: number) => String(n).padStart(2, '0');
  return h > 0 ? `${h}:${pad(m)}:${pad(s)}` : `${pad(m)}:${pad(s)}`;
}
