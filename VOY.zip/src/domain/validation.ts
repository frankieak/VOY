import type { LocationPoint } from './types';

/* Validación estricta de entradas. Sin dependencias de UI. */

export type ParseResult<T> = { ok: true; value: T } | { ok: false; error: string };

const NUMERIC = /^[+-]?(\d+(\.\d+)?|\.\d+)$/;

export const LAT_RANGE = { min: -90, max: 90 } as const;
export const LNG_RANGE = { min: -180, max: 180 } as const;
export const SPEED_RANGE_KMH = { min: 0.1, max: 300 } as const;
export const INTERVAL_RANGE_MS = { min: 100, max: 10_000 } as const;
export const ACCURACY_RANGE_M = { min: 3, max: 15 } as const;

export function isValidLatitude(value: number): boolean {
  return Number.isFinite(value) && value >= LAT_RANGE.min && value <= LAT_RANGE.max;
}

export function isValidLongitude(value: number): boolean {
  return Number.isFinite(value) && value >= LNG_RANGE.min && value <= LNG_RANGE.max;
}

/** Convierte texto a número dentro de un rango. Acepta coma decimal. */
export function parseNumberInRange(
  raw: string,
  min: number,
  max: number,
  label: string,
  integer = false,
): ParseResult<number> {
  const normalized = raw.trim().replace(',', '.');
  if (normalized === '') return { ok: false, error: `${label} es obligatorio.` };
  if (!NUMERIC.test(normalized)) return { ok: false, error: `${label} debe ser un número válido.` };
  const value = Number(normalized);
  if (integer && !Number.isInteger(value)) return { ok: false, error: `${label} debe ser un entero.` };
  if (value < min || value > max) return { ok: false, error: `${label} debe estar entre ${min} y ${max}.` };
  return { ok: true, value };
}

export function parseLatitude(raw: string): ParseResult<number> {
  return parseNumberInRange(raw, LAT_RANGE.min, LAT_RANGE.max, 'La latitud');
}

export function parseLongitude(raw: string): ParseResult<number> {
  return parseNumberInRange(raw, LNG_RANGE.min, LNG_RANGE.max, 'La longitud');
}

export type CoordinatePairResult =
  | { ok: true; point: LocationPoint }
  | { ok: false; latitudeError: string | null; longitudeError: string | null };

export function parseCoordinatePair(latRaw: string, lngRaw: string): CoordinatePairResult {
  const lat = parseLatitude(latRaw);
  const lng = parseLongitude(lngRaw);
  if (lat.ok && lng.ok) {
    return { ok: true, point: { latitude: lat.value, longitude: lng.value } };
  }
  return {
    ok: false,
    latitudeError: lat.ok ? null : lat.error,
    longitudeError: lng.ok ? null : lng.error,
  };
}
