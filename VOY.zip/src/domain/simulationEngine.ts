import { jitterPoint, kmhToMs } from './geo';
import { buildRouteIndex, positionAlongRoute } from './route';
import type { LocationFix, SimulationConfig } from './types';

/*
 * MOTOR DE SIMULACIÓN (función pura, sin React ni timers).
 * Equivalente Kotlin: `object SimulationEngine { fun advance(...): EngineOutput? }`
 * Se invoca periódicamente desde el ViewModel / ForegroundService con el tiempo
 * transcurrido real (delta), por lo que no acumula deriva aunque el timer se retrase.
 */

export interface EngineInput {
  config: SimulationConfig;
  previousTraveledMeters: number;
  previousLap: number;
  elapsedSeconds: number;
  nowMs: number;
  random?: () => number;
}

export interface EngineOutput {
  fix: LocationFix;
  traveledMeters: number;
  totalMeters: number;
  lap: number;
  completed: boolean;
}

/** Devuelve un mensaje de error si la configuración no permite iniciar, o null si es válida. */
export function validateForStart(config: SimulationConfig): string | null {
  if (config.mode === 'POINT') {
    return config.fixedPoint ? null : 'Define un punto en el mapa antes de iniciar.';
  }
  if (config.waypoints.length < 2) return 'La ruta necesita al menos 2 puntos.';
  if (!(config.speedKmh > 0)) return 'La velocidad debe ser mayor que 0 km/h.';
  return null;
}

function toFix(
  latitude: number,
  longitude: number,
  accuracyMeters: number,
  speedMs: number,
  bearingDeg: number,
  nowMs: number,
): LocationFix {
  return { latitude, longitude, accuracyMeters, speedMs, bearingDeg, timestampMs: nowMs };
}

export function advanceSimulation(input: EngineInput): EngineOutput | null {
  const { config, previousTraveledMeters, previousLap, elapsedSeconds, nowMs, random } = input;

  if (config.mode === 'POINT') {
    if (!config.fixedPoint) return null;
    const reported = jitterPoint(config.fixedPoint, config.accuracyMeters, random);
    return {
      fix: toFix(reported.latitude, reported.longitude, config.accuracyMeters, 0, 0, nowMs),
      traveledMeters: 0,
      totalMeters: 0,
      lap: 0,
      completed: false,
    };
  }

  if (config.waypoints.length === 0) return null;

  const index = buildRouteIndex(config.waypoints);
  const total = index.totalMeters;
  const speedMs = kmhToMs(config.speedKmh);

  let traveled = previousTraveledMeters + speedMs * Math.max(0, elapsedSeconds);
  let lap = previousLap;
  let completed = false;

  if (total <= 0) {
    traveled = 0;
    completed = true;
  } else if (traveled >= total) {
    if (config.loop) {
      lap += Math.floor(traveled / total);
      traveled = traveled % total;
    } else {
      traveled = total;
      completed = true;
    }
  }

  const pos = positionAlongRoute(config.waypoints, index, traveled);
  if (!pos) return null;

  const reported = jitterPoint(pos.point, config.accuracyMeters, random);
  return {
    fix: toFix(
      reported.latitude,
      reported.longitude,
      config.accuracyMeters,
      completed ? 0 : speedMs,
      pos.bearingDeg,
      nowMs,
    ),
    traveledMeters: traveled,
    totalMeters: total,
    lap,
    completed,
  };
}
