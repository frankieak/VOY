import { bearingBetween, haversineMeters, interpolatePoint } from './geo';
import type { LocationPoint } from './types';

/*
 * Geometría de rutas (polilíneas). Equivalente en Kotlin a una clase
 * `RouteGeometry` con índice acumulado (binary search opcional para rutas largas).
 */

export interface RouteIndex {
  /** Distancia acumulada en metros hasta cada vértice. cumulative[0] = 0. */
  readonly cumulativeMeters: readonly number[];
  readonly totalMeters: number;
}

export interface RoutePosition {
  readonly point: LocationPoint;
  readonly bearingDeg: number;
  readonly segmentIndex: number;
}

export function buildRouteIndex(waypoints: readonly LocationPoint[]): RouteIndex {
  if (waypoints.length === 0) return { cumulativeMeters: [], totalMeters: 0 };
  const cumulative: number[] = [0];
  for (let i = 1; i < waypoints.length; i++) {
    cumulative.push(cumulative[i - 1] + haversineMeters(waypoints[i - 1], waypoints[i]));
  }
  return { cumulativeMeters: cumulative, totalMeters: cumulative[cumulative.length - 1] };
}

/** Posición y rumbo a `distance` metros desde el inicio de la ruta (se limita al rango). */
export function positionAlongRoute(
  waypoints: readonly LocationPoint[],
  index: RouteIndex,
  distance: number,
): RoutePosition | null {
  if (waypoints.length === 0) return null;
  if (waypoints.length === 1 || index.totalMeters <= 0) {
    return { point: waypoints[0], bearingDeg: 0, segmentIndex: 0 };
  }

  const cum = index.cumulativeMeters;
  const d = Math.min(Math.max(distance, 0), index.totalMeters);
  const lastSegment = waypoints.length - 2;

  let segment = 0;
  while (segment < lastSegment && cum[segment + 1] < d) segment++;

  const a = waypoints[segment];
  const b = waypoints[segment + 1];
  const segLength = cum[segment + 1] - cum[segment];
  const t = segLength > 0 ? Math.min(Math.max((d - cum[segment]) / segLength, 0), 1) : 0;

  return {
    point: interpolatePoint(a, b, t),
    bearingDeg: bearingBetween(a, b),
    segmentIndex: segment,
  };
}
