import { MapPin, Pin, PinOff, Route, Trash2 } from 'lucide-react';
import type { FavoriteKind, HistoryEntry, LocationPoint, SavedPoint, SimulatedRoute } from '@/domain/types';
import { formatCoordinate, formatDistance } from '@/domain/geo';
import { buildRouteIndex } from '@/domain/route';
import { cn } from '@/utils/cn';
import { Dialog, FOCUS_RING } from './ui';

export type LibraryTab = 'FAVORITES' | 'HISTORY';

interface LibraryDrawerProps {
  open: boolean;
  onClose: () => void;
  tab: LibraryTab;
  onTabChange: (tab: LibraryTab) => void;
  points: SavedPoint[];
  routes: SimulatedRoute[];
  history: HistoryEntry[];
  onLoadPoint: (point: SavedPoint) => void;
  onLoadRoute: (route: SimulatedRoute) => void;
  onTogglePin: (kind: FavoriteKind, id: string) => void;
  onRemove: (kind: FavoriteKind, id: string) => void;
  onLoadHistory: (entry: HistoryEntry) => void;
  onClearHistory: () => void;
}

const TABS: { id: LibraryTab; label: string }[] = [
  { id: 'FAVORITES', label: 'Favoritos' },
  { id: 'HISTORY', label: 'Historial' },
];

const formatTimestamp = (ms: number) =>
  new Date(ms).toLocaleString('es-ES', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });

const formatPoint = (p: LocationPoint) => `${formatCoordinate(p.latitude)}, ${formatCoordinate(p.longitude)}`;

const ACTION_BTN = cn(
  'grid h-8 w-8 place-items-center rounded-lg text-zinc-400 hover:bg-zinc-800 hover:text-zinc-100',
  FOCUS_RING,
);

/** Cajón deslizable con favoritos (puntos y rutas) e historial de ubicaciones simuladas. */
export function LibraryDrawer(props: LibraryDrawerProps) {
  const { open, onClose, tab, onTabChange, points, routes, history } = props;

  return (
    <Dialog open={open} onClose={onClose} title="Biblioteca" variant="right">
      <div role="tablist" aria-label="Secciones" className="mb-4 grid grid-cols-2 gap-1 rounded-xl border border-zinc-800 bg-zinc-900 p-1">
        {TABS.map((t) => (
          <button
            key={t.id}
            role="tab"
            type="button"
            aria-selected={tab === t.id}
            onClick={() => onTabChange(t.id)}
            className={cn(
              'rounded-lg px-3 py-2 text-sm font-medium transition',
              FOCUS_RING,
              tab === t.id ? 'bg-green-500 text-zinc-950' : 'text-zinc-400 hover:text-zinc-100',
            )}
          >
            {t.label}
            <span className="ml-1.5 font-mono text-xs opacity-70">
              {t.id === 'FAVORITES' ? points.length + routes.length : history.length}
            </span>
          </button>
        ))}
      </div>

      {tab === 'FAVORITES' ? (
        <div className="space-y-5">
          {points.length === 0 && routes.length === 0 ? (
            <p className="rounded-xl border border-dashed border-zinc-700 p-6 text-center text-sm text-zinc-500">
              Aún no tienes favoritos. Guarda un punto o una ruta desde el panel de simulación.
            </p>
          ) : null}

          {points.length > 0 ? (
            <section>
              <h3 className="mb-2 text-xs font-semibold uppercase tracking-wider text-zinc-500">Puntos</h3>
              <ul className="space-y-2">
                {points.map((item) => (
                  <li key={item.id} className="flex items-center gap-2 rounded-xl border border-zinc-800 bg-zinc-900/70 p-2.5">
                    <MapPin className="h-4 w-4 shrink-0 text-green-400" aria-hidden="true" />
                    <button type="button" onClick={() => props.onLoadPoint(item)} className="min-w-0 flex-1 text-left">
                      <span className="block truncate text-sm font-medium text-zinc-100">
                        {item.pinned ? '📌 ' : ''}
                        {item.name}
                      </span>
                      <span className="block truncate font-mono text-[11px] text-zinc-500">{formatPoint(item.point)}</span>
                    </button>
                    <button type="button" className={ACTION_BTN} onClick={() => props.onTogglePin('POINT', item.id)} aria-label={item.pinned ? 'Desfijar' : 'Fijar'}>
                      {item.pinned ? <PinOff className="h-4 w-4" /> : <Pin className="h-4 w-4" />}
                    </button>
                    <button type="button" className={cn(ACTION_BTN, 'hover:text-red-300')} onClick={() => props.onRemove('POINT', item.id)} aria-label={`Eliminar ${item.name}`}>
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </li>
                ))}
              </ul>
            </section>
          ) : null}

          {routes.length > 0 ? (
            <section>
              <h3 className="mb-2 text-xs font-semibold uppercase tracking-wider text-zinc-500">Rutas</h3>
              <ul className="space-y-2">
                {routes.map((item) => {
                  const total = buildRouteIndex(item.waypoints).totalMeters;
                  return (
                    <li key={item.id} className="flex items-center gap-2 rounded-xl border border-zinc-800 bg-zinc-900/70 p-2.5">
                      <Route className="h-4 w-4 shrink-0 text-green-400" aria-hidden="true" />
                      <button type="button" onClick={() => props.onLoadRoute(item)} className="min-w-0 flex-1 text-left">
                        <span className="block truncate text-sm font-medium text-zinc-100">
                          {item.pinned ? '📌 ' : ''}
                          {item.name}
                        </span>
                        <span className="block truncate text-[11px] text-zinc-500">
                          {item.waypoints.length} puntos · {formatDistance(total)}
                        </span>
                      </button>
                      <button type="button" className={ACTION_BTN} onClick={() => props.onTogglePin('ROUTE', item.id)} aria-label={item.pinned ? 'Desfijar' : 'Fijar'}>
                        {item.pinned ? <PinOff className="h-4 w-4" /> : <Pin className="h-4 w-4" />}
                      </button>
                      <button type="button" className={cn(ACTION_BTN, 'hover:text-red-300')} onClick={() => props.onRemove('ROUTE', item.id)} aria-label={`Eliminar ${item.name}`}>
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </li>
                  );
                })}
              </ul>
            </section>
          ) : null}
        </div>
      ) : (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <p className="text-xs text-zinc-500">Se registra automáticamente cada simulación iniciada.</p>
            {history.length > 0 ? (
              <button type="button" onClick={props.onClearHistory} className={cn('rounded-lg px-2 py-1 text-xs text-red-300 hover:bg-red-500/10', FOCUS_RING)}>
                Vaciar
              </button>
            ) : null}
          </div>
          {history.length === 0 ? (
            <p className="rounded-xl border border-dashed border-zinc-700 p-6 text-center text-sm text-zinc-500">
              Sin historial todavía.
            </p>
          ) : (
            <ul className="space-y-2">
              {history.map((entry) => (
                <li key={entry.id}>
                  <button
                    type="button"
                    onClick={() => props.onLoadHistory(entry)}
                    className={cn('flex w-full items-center gap-3 rounded-xl border border-zinc-800 bg-zinc-900/70 p-2.5 text-left hover:border-zinc-600', FOCUS_RING)}
                  >
                    <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-zinc-800 font-mono text-[10px] text-zinc-300">
                      {entry.mode === 'ROUTE' ? 'RUT' : 'PTO'}
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-sm text-zinc-100">{entry.label}</span>
                      <span className="block truncate font-mono text-[11px] text-zinc-500">{formatPoint(entry.point)}</span>
                    </span>
                    <span className="shrink-0 text-[11px] text-zinc-500">{formatTimestamp(entry.timestampMs)}</span>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </Dialog>
  );
}
