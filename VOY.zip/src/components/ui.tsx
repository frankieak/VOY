import { useEffect, useState, type ButtonHTMLAttributes, type FormEvent, type ReactNode } from 'react';
import { CircleAlert, CircleCheck, Info, X } from 'lucide-react';
import { cn } from '@/utils/cn';

/* Primitivas de interfaz reutilizables (sin lógica de dominio). */

type ButtonVariant = 'primary' | 'secondary' | 'danger' | 'amber' | 'ghost';

const BUTTON_VARIANTS: Record<ButtonVariant, string> = {
  primary: 'bg-green-500 text-zinc-950 font-semibold hover:bg-green-400 shadow-lg shadow-green-500/20',
  secondary: 'bg-zinc-800 text-zinc-100 border border-zinc-700 hover:bg-zinc-700',
  danger: 'bg-transparent text-red-400 border border-red-500/40 hover:bg-red-500/10',
  amber: 'bg-amber-400 text-zinc-950 font-semibold hover:bg-amber-300',
  ghost: 'bg-transparent text-zinc-300 hover:bg-zinc-800 hover:text-white',
};

export const FOCUS_RING =
  'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-green-400 focus-visible:ring-offset-2 focus-visible:ring-offset-zinc-950';

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
}

export function Button({ variant = 'secondary', className, ...props }: ButtonProps) {
  return (
    <button
      type="button"
      className={cn(
        'inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm transition active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-40',
        FOCUS_RING,
        BUTTON_VARIANTS[variant],
        className,
      )}
      {...props}
    />
  );
}

interface IconButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  label: string;
  active?: boolean;
}

export function IconButton({ label, active = false, className, children, ...props }: IconButtonProps) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      aria-pressed={props['aria-pressed'] ?? undefined}
      className={cn(
        'grid h-10 w-10 shrink-0 place-items-center rounded-xl border transition active:scale-95 disabled:cursor-not-allowed disabled:opacity-40',
        FOCUS_RING,
        active
          ? 'border-green-500/60 bg-green-500/15 text-green-300'
          : 'border-zinc-700/80 bg-zinc-900/90 text-zinc-200 hover:bg-zinc-800 hover:text-white',
        className,
      )}
      {...props}
    >
      {children}
    </button>
  );
}

interface SegmentedProps<T extends string> {
  options: { value: T; label: string }[];
  value: T;
  onChange: (value: T) => void;
  ariaLabel: string;
  className?: string;
}

export function Segmented<T extends string>({ options, value, onChange, ariaLabel, className }: SegmentedProps<T>) {
  return (
    <div
      role="group"
      aria-label={ariaLabel}
      className={cn('grid gap-1 rounded-xl border border-zinc-800 bg-zinc-900 p-1', className)}
      style={{ gridTemplateColumns: `repeat(${options.length}, minmax(0, 1fr))` }}
    >
      {options.map((opt) => {
        const selected = opt.value === value;
        return (
          <button
            key={opt.value}
            type="button"
            aria-pressed={selected}
            onClick={() => onChange(opt.value)}
            className={cn(
              'rounded-lg px-3 py-2 text-sm font-medium transition',
              FOCUS_RING,
              selected ? 'bg-green-500 text-zinc-950 shadow' : 'text-zinc-400 hover:text-zinc-100',
            )}
          >
            {opt.label}
          </button>
        );
      })}
    </div>
  );
}

export function Field({ label, error, children, className }: { label: string; error?: string | null; children: ReactNode; className?: string }) {
  return (
    <label className={cn('flex min-w-0 flex-col gap-1', className)}>
      <span className="text-[11px] font-semibold uppercase tracking-wider text-zinc-500">{label}</span>
      {children}
      {error ? <span className="text-xs text-red-400">{error}</span> : null}
    </label>
  );
}

export const INPUT_CLASS = cn(
  'w-full rounded-xl border border-zinc-700 bg-zinc-900 px-3 py-2.5 text-sm text-zinc-100 placeholder:text-zinc-600 transition',
  'focus:border-green-500 focus:outline-none focus:ring-1 focus:ring-green-500',
);

interface NameSaveFormProps {
  placeholder: string;
  buttonLabel: string;
  onSave: (name: string) => void;
  disabled?: boolean;
}

/** Formulario compacto: nombre + botón para guardar en favoritos. */
export function NameSaveForm({ placeholder, buttonLabel, onSave, disabled = false }: NameSaveFormProps) {
  const [name, setName] = useState('');
  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (disabled) return;
    onSave(name);
    setName('');
  };
  return (
    <form onSubmit={submit} className="flex gap-2">
      <input
        value={name}
        onChange={(e) => setName(e.target.value)}
        maxLength={60}
        placeholder={placeholder}
        aria-label={placeholder}
        className={INPUT_CLASS}
      />
      <Button type="submit" variant="secondary" disabled={disabled} className="shrink-0">
        {buttonLabel}
      </Button>
    </form>
  );
}

export interface ToastMessage {
  id: number;
  message: string;
  tone: 'info' | 'success' | 'error';
}

const TOAST_STYLES: Record<ToastMessage['tone'], { cls: string; Icon: typeof Info }> = {
  info: { cls: 'border-zinc-700 bg-zinc-900/95 text-zinc-100', Icon: Info },
  success: { cls: 'border-green-500/40 bg-green-950/90 text-green-100', Icon: CircleCheck },
  error: { cls: 'border-red-500/40 bg-red-950/90 text-red-100', Icon: CircleAlert },
};

export function Toast({ toast }: { toast: ToastMessage | null }) {
  if (!toast) return null;
  const { cls, Icon } = TOAST_STYLES[toast.tone];
  return (
    <div
      key={toast.id}
      role="status"
      aria-live="polite"
      className={cn(
        'pointer-events-auto flex items-center gap-2 rounded-xl border px-3 py-2 text-sm shadow-xl backdrop-blur animate-[voy-fade_.2s_ease-out]',
        cls,
      )}
    >
      <Icon className="h-4 w-4 shrink-0" aria-hidden="true" />
      <span className="min-w-0">{toast.message}</span>
    </div>
  );
}

interface DialogProps {
  open: boolean;
  onClose: () => void;
  title: string;
  variant?: 'center' | 'right';
  children: ReactNode;
}

/** Modal centrado o cajón lateral. Cierra con Escape y al pulsar el fondo. */
export function Dialog({ open, onClose, title, variant = 'center', children }: DialogProps) {
  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[1000]">
      <button
        type="button"
        aria-label="Cerrar"
        onClick={onClose}
        className="absolute inset-0 cursor-default bg-black/60 backdrop-blur-sm animate-[voy-fade_.2s_ease-out]"
      />
      <section
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className={cn(
          'absolute flex flex-col border-zinc-800 bg-zinc-950 shadow-2xl animate-[voy-slide_.25s_ease-out]',
          variant === 'center'
            ? 'inset-x-3 top-1/2 mx-auto max-h-[88dvh] max-w-lg -translate-y-1/2 rounded-2xl border'
            : 'inset-y-0 right-0 w-full max-w-md border-l',
        )}
      >
        <header className="flex items-center justify-between gap-3 border-b border-zinc-800 px-4 py-3">
          <h2 className="text-base font-semibold text-white">{title}</h2>
          <IconButton label="Cerrar" onClick={onClose}>
            <X className="h-5 w-5" />
          </IconButton>
        </header>
        <div className="min-h-0 flex-1 overflow-y-auto p-4">{children}</div>
      </section>
    </div>
  );
}
