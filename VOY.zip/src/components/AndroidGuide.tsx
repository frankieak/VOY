import { AlertTriangle, Smartphone } from 'lucide-react';

interface GuideStep {
  title: string;
  body: string;
}

/* Pasos para la versión nativa (Kotlin): permiso de ubicación simulada en Android. */
const STEPS: GuideStep[] = [
  {
    title: 'Activa las Opciones de desarrollador',
    body: 'Ve a Ajustes → Acerca del teléfono → Información de software (en Samsung: Información del software) y toca "Número de compilación" 7 veces hasta ver el aviso "Ya eres desarrollador".',
  },
  {
    title: 'Abre Opciones de desarrollador',
    body: 'En Ajustes → Sistema → Opciones de desarrollador. En algunos fabricantes aparece directamente en la raíz de Ajustes.',
  },
  {
    title: 'Localiza la aplicación de ubicación simulada',
    body: 'Desplázate hasta la sección "Depuración" y busca "Seleccionar aplicación para ubicación simulada". En Android 13 y superiores puede aparecer como "Aplicación de ubicación simulada".',
  },
  {
    title: 'Elige VOY',
    body: 'Pulsa la opción, selecciona "VOY" en la lista de aplicaciones y confirma. No necesitas permisos de root.',
  },
  {
    title: 'Inicia la simulación',
    body: 'Vuelve a VOY, define un punto o una ruta e inicia la simulación. Verás la notificación persistente "Ubicación simulada activa". Comprueba el resultado en Google Maps: el punto azul debe aparecer en la posición simulada.',
  },
  {
    title: 'Desactívala al terminar',
    body: 'Cuando acabes, detén la simulación en VOY y vuelve a Opciones de desarrollador para seleccionar "Ninguna aplicación" como ubicación simulada, así tu GPS real volverá a utilizarse.',
  },
];

export function AndroidGuide() {
  return (
    <div className="space-y-5">
      <div className="flex items-start gap-3 rounded-xl border border-green-500/30 bg-green-500/10 p-3">
        <Smartphone className="mt-0.5 h-5 w-5 shrink-0 text-green-300" aria-hidden="true" />
        <p className="text-sm text-green-100">
          Esta guía prepara la versión nativa en Kotlin: la app usará un proveedor de pruebas
          (<span className="font-mono">addTestProvider</span>) mediante el permiso{' '}
          <span className="font-mono">ACCESS_MOCK_LOCATION</span>.
        </p>
      </div>

      <ol className="space-y-3">
        {STEPS.map((step, i) => (
          <li key={step.title} className="flex gap-3">
            <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full border border-green-500/60 bg-green-500/10 font-mono text-xs font-bold text-green-300">
              {i + 1}
            </span>
            <div className="min-w-0">
              <h4 className="text-sm font-semibold text-zinc-100">{step.title}</h4>
              <p className="mt-0.5 text-sm leading-relaxed text-zinc-400">{step.body}</p>
            </div>
          </li>
        ))}
      </ol>

      <div className="flex items-start gap-3 rounded-xl border border-amber-500/30 bg-amber-500/10 p-3">
        <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-amber-300" aria-hidden="true" />
        <p className="text-xs leading-relaxed text-amber-100">
          Úsala con responsabilidad: pruebas de desarrollo y de tus propias aplicaciones. Muchas apps
          (bancos, juegos, servicios de emergencia) detectan ubicaciones simuladas y no respetan la
          simulación.
        </p>
      </div>
    </div>
  );
}
