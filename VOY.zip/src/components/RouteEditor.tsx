import { useState, type FormEvent } from 'react';
import { Bike, Car, Footprints, Repeat, Trash2, Undo2, X } from 'lucide-react';
import type { LocationPoint } from '@/domain/types';
import { formatCoordinate, formatDistance, formatDuration, kmhToMs } from '@/domain/geo';
import { buildRouteIndex } from '@/domain/route';
import { parseNumberInRange, SPEED_RANGE_KMH } from '@/domain/validation';
import { cn } from '@/utils/cn';
import { Button, FOCUS_RING, INPUT_CLASS, NameSaveForm } from './ui';

interface RouteEditorProps {
  waypoints: LocationPoint[];
  speedKmh: number;
  loop: boolean;
  onSpeedChange: (kmh: number) => void;
  onLoopChange: (loop: boolean) => void;
  onRemove: (index: number) => void;
  onUndo: () => void;
  onClear: () => void;
  onSaveRoute: (name: string) => void;
}

const PRESETS = [
  { label: 'Caminar', kmh: 5, Icon: Footprints },
  { label: 'Bicicleta', kmh: 20, Icon: Bike },
  { label: 'Auto', kmh: 60, Icon: Car },
] as const;

/** Edición de la ruta: puntos, velocidad (presets + manual), bucle y guardado. */
export function RouteEditor({
  waypoints,
  speedKmh,
  loop,
  onSpeedChange,
  onLoopChange,
  onRemove,
  onUndo,
  onClear,
  onSaveRoute,
}: RouteEditorProps) {
  // Borrador del campo de velocidad; null = mostrar el valor real.
  const [draft, setDraft] = useState<string | null>(null);
  const [speedError, setSpeedError] = useState<string | null>(null);

  const index = buildRouteIndex(waypoints);
  const speedMs = kmhToMs(speedKmh);
  const duration = speedMs > 0 ? index.totalMeters / speedMs : NaN;

  const applySpeed = (event?: FormEvent) => {
    event?.preventDefault();
    const result = parseNumberInRange(draft ?? String(speedKmh), SPEED_RANGE_KMH.min, SPEED_RANGE_KMH.max, 'La velocidad');
    if (!result.ok) {
      setSpeedError(result.error);
      return;
    }
    setSpeedError(null);
    setDraft(null);
    onSpeedChange(result.value);
  };

  return (
    <div className="space-y-4">
      {/* Puntos de la ruta */}
      <section>
        <div className="mb-2 flex items-center justify-between">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-zinc-400">
            Puntos de ruta <span className="font-mono text-zinc-500">({waypoints.length})</span>
          </h3>
          <div className="flex gap-1">
            <button
              type="button"
              onClick={onUndo}
              disabled={waypoints.length === 0}
              aria-label="Deshacer último punto"
              className={cn('grid h-8 w-8 place-items-center rounded-lg text-zinc-300 hover:bg-zinc-800 disabled:opacity-30', FOCUS_RING)}
            >
              <Undo2 className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={onClear}
              disabled={waypoints.length === 0}
              aria-label="Borrar toda la ruta"
              className={cn('grid h-8 w-8 place-items-center rounded-lg text-red-300 hover:bg-red-500/10 disabled:opacity-30', FOCUS_RING)}
            >
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        </div>

        {waypoints.length === 0 ? (
          <p className="rounded-xl border border-dashed border-zinc-700 p-3 text-center text-sm text-zinc-500">
            Toca el mapa para añadir puntos. Necesitas al menos 2.
          </p>
        ) : (
          <ol className="max-h-40 space-y-1.5 overflow-y-auto pr-1">
            {waypoints.map((wp, i) => (
              <li key={`${i}-${wp.latitude}-${wp.longitude}`} className="flex items-center gap-2 rounded-lg bg-zinc-900/80 px-2 py-1.5">
                <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full border border-green-500 text-[11px] font-bold text-green-300">
                  {i + 1}
                </span>
                <span className="min-w-0 flex-1 truncate font-mono text-xs text-zinc-300">
                  {formatCoordinate(wp.latitude)}, {formatCoordinate(wp.longitude)}
                </span>
                <button
                  type="button"
                  onClick={() => onRemove(i)}
                  aria-label={`Eliminar punto ${i + 1}`}
                  className={cn('grid h-7 w-7 shrink-0 place-items-center rounded-md text-zinc-500 hover:bg-zinc-800 hover:text-red-300', FOCUS_RING)}
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </li>
            ))}
          </ol>
        )}

        {waypoints.length >= 2 ? (
          <p className="mt-2 text-xs text-zinc-400">
            Distancia <span className="font-mono text-zinc-200">{formatDistance(index.totalMeters)}</span>
            {' · '}Tiempo estimado <span className="font-mono text-zinc-200">{formatDuration(duration)}</span>
            {loop ? ' por vuelta' : ''}
          </p>
        ) : null}
      </section>

      {/* Velocidad */}
      <section>
        <h3 className="mb-2 text-xs font-semibold uppercase tracking-wider text-zinc-400">Velocidad</h3>
        <div className="grid grid-cols-3 gap-2">
          {PRESETS.map(({ label, kmh, Icon }) => {
            const selected = Math.abs(speedKmh - kmh) < 0.001 && draft === null;
            return (
              <button
                key={label}
                type="button"
                aria-pressed={selected}
                onClick={() => {
                  setDraft(null);
                  setSpeedError(null);
                  onSpeedChange(kmh);
                }}
                className={cn(
                  'flex flex-col items-center gap-1 rounded-xl border px-2 py-2.5 text-xs transition',
                  FOCUS_RING,
                  selected
                    ? 'border-green-500 bg-green-500/15 text-green-200'
                    : 'border-zinc-700 bg-zinc-900 text-zinc-300 hover:border-zinc-600',
                )}
              >
                <Icon className="h-4 w-4" aria-hidden="true" />
                <span className="font-semibold">{label}</span>
                <span className="font-mono text-[11px] text-zinc-500">{kmh} km/h</span>
              </button>
            );
          })}
        </div>
        <form onSubmit={applySpeed} noValidate className="mt-2 flex items-start gap-2">
          <label className="min-w-0 flex-1">
            <span className="sr-only">Velocidad personalizada en km/h</span>
            <div className="relative">
              <input
                inputMode="decimal"
                value={draft ?? String(speedKmh)}
                onChange={(e) => {
                  setDraft(e.target.value);
                  setSpeedError(null);
                }}
                onBlur={() => applySpeed()}
                aria-invalid={speedError ? true : undefined}
                className={cn(INPUT_CLASS, 'pr-16 font-mono')}
              />
              <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-xs text-zinc-500">km/h</span>
            </div>
            {speedError ? <span className="mt-1 block text-xs text-red-400">{speedError}</span> : null}
          </label>
          <Button type="submit" variant="secondary" className="shrink-0 px-3 py-2.5">
            Aplicar
          </Button>
        </form>
      </section>

      {/* Bucle */}
      <section className="flex items-center justify-between rounded-xl border border-zinc-800 bg-zinc-900/70 px-3 py-2.5">
        <div className="flex items-center gap-2 text-sm text-zinc-200">
          <Repeat className="h-4 w-4 text-zinc-400" aria-hidden="true" />
          Repetir en bucle
        </div>
        <button
          type="button"
          role="switch"
          aria-checked={loop}
          aria-label="Repetir en bucle"
          onClick={() => onLoopChange(!loop)}
          className={cn(
            'relative h-6 w-11 rounded-full transition',
            FOCUS_RING,
            loop ? 'bg-green-500' : 'bg-zinc-700',
          )}
        >
          <span
            className={cn(
              'absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all',
              loop ? 'left-[22px]' : 'left-0.5',
            )}
          />
        </button>
      </section>

      {/* Guardar */}
      <section>
        <h3 className="mb-2 text-xs font-semibold uppercase tracking-wider text-zinc-400">Guardar ruta</h3>
        <NameSaveForm
          placeholder="Nombre de la ruta"
          buttonLabel="Guardar"
          disabled={waypoints.length < 2}
          onSave={onSaveRoute}
        />
      </section>
    </div>
  );
}
