import { Crosshair, LocateFixed, Loader2, Minus, Navigation, Plus } from 'lucide-react';
import { IconButton } from './ui';
import { cn } from '@/utils/cn';

interface MapControlsProps {
  className?: string;
  follow: boolean;
  hasFix: boolean;
  locating: boolean;
  onToggleFollow: () => void;
  onZoomIn: () => void;
  onZoomOut: () => void;
  onLocate: () => void;
  onCenterSimulation: () => void;
}

/** Botones flotantes del mapa: zoom, mi ubicación, punto simulado y seguimiento. */
export function MapControls({
  className,
  follow,
  hasFix,
  locating,
  onToggleFollow,
  onZoomIn,
  onZoomOut,
  onLocate,
  onCenterSimulation,
}: MapControlsProps) {
  return (
    <div className={cn('flex flex-row items-center gap-2 md:flex-col', className)}>
      <div className="flex flex-row overflow-hidden rounded-xl border border-zinc-700/80 bg-zinc-900/90 shadow-lg md:flex-col">
        <button
          type="button"
          onClick={onZoomIn}
          aria-label="Acercar"
          className="grid h-10 w-10 place-items-center text-zinc-200 hover:bg-zinc-800 active:bg-zinc-700"
        >
          <Plus className="h-5 w-5" />
        </button>
        <span className="h-6 w-px bg-zinc-700/80 md:h-px md:w-10" />
        <button
          type="button"
          onClick={onZoomOut}
          aria-label="Alejar"
          className="grid h-10 w-10 place-items-center text-zinc-200 hover:bg-zinc-800 active:bg-zinc-700"
        >
          <Minus className="h-5 w-5" />
        </button>
      </div>

      <IconButton label="Centrar en mi ubicación" onClick={onLocate} disabled={locating} className="shadow-lg">
        {locating ? <Loader2 className="h-5 w-5 animate-spin" /> : <LocateFixed className="h-5 w-5" />}
      </IconButton>
      <IconButton
        label="Centrar en el punto simulado"
        onClick={onCenterSimulation}
        disabled={!hasFix}
        className="shadow-lg"
      >
        <Navigation className="h-5 w-5" />
      </IconButton>
      <IconButton
        label={follow ? 'Dejar de seguir la simulación' : 'Seguir la simulación'}
        active={follow}
        aria-pressed={follow}
        onClick={onToggleFollow}
        className="shadow-lg"
      >
        <Crosshair className="h-5 w-5" />
      </IconButton>
    </div>
  );
}
