import { ChevronDown, ChevronUp, Pause, Play, Square } from 'lucide-react';
import type { LocationPoint, SimulationMode, SimulationState, SpeedUnit } from '@/domain/types';
import { formatCoordinate } from '@/domain/geo';
import { ACCURACY_RANGE_M } from '@/domain/validation';
import { cn } from '@/utils/cn';
import { Button, FOCUS_RING, NameSaveForm, Segmented } from './ui';
import { StatusPill, TelemetryGrid } from './TelemetryCard';
import { RouteEditor } from './RouteEditor';

export interface ControlSheetProps {
  className?: string;
  collapsed: boolean;
  onToggleCollapsed: () => void;
  mode: SimulationMode;
  onModeChange: (mode: SimulationMode) => void;
  fixedPoint: LocationPoint | null;
  onSavePoint: (name: string) => void;
  waypoints: LocationPoint[];
  onWaypointRemove: (index: number) => void;
  onUndoWaypoint: () => void;
  onClearRoute: () => void;
  onSaveRoute: (name: string) => void;
  speedKmh: number;
  onSpeedChange: (kmh: number) => void;
  loop: boolean;
  onLoopChange: (loop: boolean) => void;
  accuracyMeters: number;
  onAccuracyChange: (meters: number) => void;
  speedUnit: SpeedUnit;
  state: SimulationState;
  onStart: () => void;
  onPause: () => void;
  onResume: () => void;
  onStop: () => void;
}

const MODE_OPTIONS: { value: SimulationMode; label: string }[] = [
  { value: 'POINT', label: 'Punto fijo' },
  { value: 'ROUTE', label: 'Ruta / movimiento' },
];

/** Panel inferior (móvil) / lateral (escritorio): estado, controles y configuración. */
export function ControlSheet(props: ControlSheetProps) {
  const {
    className,
    collapsed,
    onToggleCollapsed,
    mode,
    onModeChange,
    fixedPoint,
    onSavePoint,
    state,
    accuracyMeters,
    onAccuracyChange,
    onStart,
    onPause,
    onResume,
    onStop,
  } = props;

  const { status } = state;
  const isRunning = status === 'RUNNING';
  const isPaused = status === 'PAUSED';
  const isActive = isRunning || isPaused;
  const headerPoint = state.currentFix ?? (mode === 'POINT' ? fixedPoint : null);

  return (
    <section
      aria-label="Panel de simulación"
      className={cn(
        'pointer-events-auto flex flex-col rounded-t-3xl border border-b-0 border-zinc-800 bg-zinc-950/95 shadow-[0_-12px_40px_rgba(0,0,0,0.55)] backdrop-blur-md md:rounded-2xl md:border-b',
        className,
      )}
    >
      {/* Cabecera siempre visible */}
      <div className="px-4 pb-3 pt-2 md:pt-4">
        <button
          type="button"
          onClick={onToggleCollapsed}
          aria-expanded={!collapsed}
          aria-label={collapsed ? 'Expandir panel' : 'Contraer panel'}
          className={cn('mx-auto mb-2 flex w-full items-center justify-center gap-2 rounded-lg py-0.5 md:hidden', FOCUS_RING)}
        >
          <span className="h-1.5 w-12 rounded-full bg-zinc-700" />
        </button>

        <div className="flex items-center justify-between gap-2">
          <StatusPill status={status} />
          <button
            type="button"
            onClick={onToggleCollapsed}
            aria-label={collapsed ? 'Expandir panel' : 'Contraer panel'}
            className={cn('hidden h-8 w-8 place-items-center rounded-lg text-zinc-400 hover:bg-zinc-800 md:grid', FOCUS_RING)}
          >
            {collapsed ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
          </button>
        </div>
        <p className="mt-1.5 truncate font-mono text-xs text-zinc-400">
          {headerPoint
            ? `${formatCoordinate(headerPoint.latitude)}, ${formatCoordinate(headerPoint.longitude)}`
            : 'Sin posición simulada'}
        </p>

        {/* Controles de transporte */}
        <div className="mt-3 grid grid-cols-3 gap-2">
          <Button variant="primary" onClick={onStart} disabled={isActive} className="px-2">
            <Play className="h-4 w-4" aria-hidden="true" />
            Iniciar
          </Button>
          {isPaused ? (
            <Button variant="secondary" onClick={onResume} className="border-green-500/50 px-2 text-green-200">
              <Play className="h-4 w-4" aria-hidden="true" />
              Reanudar
            </Button>
          ) : (
            <Button variant="amber" onClick={onPause} disabled={!isRunning} className="px-2">
              <Pause className="h-4 w-4" aria-hidden="true" />
              Pausar
            </Button>
          )}
          <Button variant="danger" onClick={onStop} disabled={!isActive && status !== 'COMPLETED'} className="px-2">
            <Square className="h-4 w-4" aria-hidden="true" />
            Detener
          </Button>
        </div>
      </div>

      {/* Cuerpo desplegable */}
      {!collapsed ? (
        <div className="max-h-[44dvh] min-h-0 space-y-5 overflow-y-auto border-t border-zinc-800 px-4 py-4 md:max-h-[calc(100dvh-22rem)]">
          <TelemetryGrid
            state={state}
            fixedPoint={fixedPoint}
            accuracyMeters={accuracyMeters}
            speedUnit={props.speedUnit}
            loop={props.loop}
          />

          <section>
            <h3 className="mb-2 text-xs font-semibold uppercase tracking-wider text-zinc-400">Modo de simulación</h3>
            <Segmented options={MODE_OPTIONS} value={mode} onChange={onModeChange} ariaLabel="Modo de simulación" />
          </section>

          {mode === 'POINT' ? (
            <section className="space-y-3">
              <p className="text-sm text-zinc-400">
                Toca el mapa o arrastra el marcador verde para fijar la posición simulada.
              </p>
              <p className="font-mono text-xs text-zinc-300">
                {fixedPoint
                  ? `Lat ${formatCoordinate(fixedPoint.latitude)} · Lng ${formatCoordinate(fixedPoint.longitude)}`
                  : 'Sin punto definido'}
              </p>
              <div>
                <h3 className="mb-2 text-xs font-semibold uppercase tracking-wider text-zinc-400">Guardar punto</h3>
                <NameSaveForm
                  placeholder="Nombre del punto"
                  buttonLabel="Guardar"
                  disabled={!fixedPoint}
                  onSave={onSavePoint}
                />
              </div>
            </section>
          ) : (
            <RouteEditor
              waypoints={props.waypoints}
              speedKmh={props.speedKmh}
              loop={props.loop}
              onSpeedChange={props.onSpeedChange}
              onLoopChange={props.onLoopChange}
              onRemove={props.onWaypointRemove}
              onUndo={props.onUndoWaypoint}
              onClear={props.onClearRoute}
              onSaveRoute={props.onSaveRoute}
            />
          )}

          <section>
            <div className="mb-2 flex items-center justify-between">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-zinc-400">Precisión simulada</h3>
              <span className="font-mono text-sm text-green-300">±{accuracyMeters} m</span>
            </div>
            <input
              type="range"
              min={ACCURACY_RANGE_M.min}
              max={ACCURACY_RANGE_M.max}
              step={1}
              value={accuracyMeters}
              onChange={(e) => onAccuracyChange(Number(e.target.value))}
              aria-label="Precisión simulada en metros"
              className="w-full accent-green-500"
            />
            <div className="mt-1 flex justify-between text-[10px] text-zinc-600">
              <span>{ACCURACY_RANGE_M.min} m</span>
              <span>{ACCURACY_RANGE_M.max} m</span>
            </div>
          </section>

          <p className="border-t border-zinc-800 pt-3 text-center text-[11px] text-zinc-600">
            Mapa © OpenStreetMap contributors · Sin publicidad · Sin compras
          </p>
        </div>
      ) : null}
    </section>
  );
}
