interface VoyLogoProps {
  className?: string;
}

/** Logotipo: pin de ubicación verde con sombrero fedora y gafas (modo incógnito). */
export function VoyLogo({ className }: VoyLogoProps) {
  return (
    <svg
      viewBox="0 0 48 48"
      className={className}
      role="img"
      aria-label="Logotipo de VOY"
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        <linearGradient id="voy-logo-pin" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#4ADE80" />
          <stop offset="1" stopColor="#16A34A" />
        </linearGradient>
      </defs>
      {/* Pin de ubicación */}
      <path d="M24 46C24 46 9 30.2 9 19a15 15 0 0 1 30 0c0 11.2-15 27-15 27z" fill="url(#voy-logo-pin)" />
      <circle cx="24" cy="19" r="10.5" fill="#052E16" fillOpacity="0.25" />
      {/* Sombrero fedora */}
      <ellipse cx="24" cy="15.2" rx="10.5" ry="2.4" fill="#0A0F0D" stroke="#86EFAC" strokeWidth="0.9" />
      <path
        d="M17.6 15.2C17.6 9.6 20 7.6 24 7.6s6.4 2 6.4 7.6z"
        fill="#0A0F0D"
        stroke="#86EFAC"
        strokeWidth="0.9"
        strokeLinejoin="round"
      />
      <rect x="17.7" y="12.6" width="12.6" height="2" fill="#22C55E" />
      {/* Gafas de incógnito */}
      <rect x="15.5" y="20" width="6.4" height="3.4" rx="1.2" fill="#0A0F0D" />
      <rect x="26.1" y="20" width="6.4" height="3.4" rx="1.2" fill="#0A0F0D" />
      <path d="M21.9 21.4h4.2" stroke="#0A0F0D" strokeWidth="1" />
    </svg>
  );
}
