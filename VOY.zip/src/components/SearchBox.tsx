import { Loader2, MapPin, Search, X } from 'lucide-react';
import type { PlaceResult } from '@/services/nominatim';
import type { PlaceSearch } from '@/hooks/usePlaceSearch';
import { formatCoordinate } from '@/domain/geo';
import { FOCUS_RING } from './ui';
import { cn } from '@/utils/cn';

interface SearchBoxProps {
  search: PlaceSearch;
  onPick: (place: PlaceResult) => void;
}

/** Buscador de lugares (Nominatim) con estado de carga, error y resultados. */
export function SearchBox({ search, onPick }: SearchBoxProps) {
  const showResults = search.query.trim().length >= 3 && (search.results.length > 0 || search.error);

  return (
    <div className="relative">
      <div className="relative flex items-center">
        <Search className="pointer-events-none absolute left-3 h-4 w-4 text-zinc-500" aria-hidden="true" />
        <input
          type="text"
          value={search.query}
          onChange={(e) => search.updateQuery(e.target.value)}
          placeholder="Buscar lugar o dirección…"
          aria-label="Buscar lugar o dirección"
          autoComplete="off"
          className={cn(
            'w-full rounded-xl border border-zinc-700 bg-zinc-900 py-2.5 pl-9 pr-16 text-sm text-zinc-100 placeholder:text-zinc-500',
            'focus:border-green-500 focus:outline-none focus:ring-1 focus:ring-green-500',
          )}
        />
        <div className="absolute right-2 flex items-center gap-1">
          {search.loading ? (
            <Loader2 className="h-4 w-4 animate-spin text-green-400" aria-label="Buscando" />
          ) : null}
          {search.query ? (
            <button
              type="button"
              onClick={search.clear}
              aria-label="Limpiar búsqueda"
              className={cn('grid h-7 w-7 place-items-center rounded-lg text-zinc-400 hover:bg-zinc-800 hover:text-white', FOCUS_RING)}
            >
              <X className="h-4 w-4" />
            </button>
          ) : null}
        </div>
      </div>

      {showResults ? (
        <div className="absolute left-0 right-0 top-full z-20 mt-2 max-h-72 overflow-y-auto rounded-xl border border-zinc-700 bg-zinc-950 shadow-2xl">
          {search.error ? <p className="px-3 py-2.5 text-xs text-amber-300">{search.error}</p> : null}
          <ul className="divide-y divide-zinc-800/80">
            {search.results.map((place) => (
              <li key={place.id}>
                <button
                  type="button"
                  onClick={() => onPick(place)}
                  className={cn('flex w-full items-start gap-3 px-3 py-2.5 text-left hover:bg-zinc-800/80', FOCUS_RING)}
                >
                  <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-green-400" aria-hidden="true" />
                  <span className="min-w-0">
                    <span className="block truncate text-sm text-zinc-100">{place.label}</span>
                    <span className="font-mono text-[11px] text-zinc-500">
                      {formatCoordinate(place.point.latitude)}, {formatCoordinate(place.point.longitude)}
                    </span>
                  </span>
                </button>
              </li>
            ))}
          </ul>
          <p className="border-t border-zinc-800 px-3 py-1.5 text-[10px] text-zinc-600">Búsqueda © Nominatim / OpenStreetMap</p>
        </div>
      ) : null}
    </div>
  );
}
