import type { LocationPoint, SimulationState, SimulationStatus, SpeedUnit } from '@/domain/types';
import { formatBearing, formatCoordinate, formatDistance, formatSpeed } from '@/domain/geo';
import { cn } from '@/utils/cn';

const STATUS_STYLES: Record<SimulationStatus, { label: string; text: string; dot: string; ping: boolean; ring: string }> = {
  IDLE: { label: 'INACTIVA', text: 'text-zinc-400', dot: 'bg-zinc-600', ping: false, ring: 'border-zinc-700 bg-zinc-900' },
  RUNNING: {
    label: 'SIMULACIÓN ACTIVA',
    text: 'text-green-300',
    dot: 'bg-green-400',
    ping: true,
    ring: 'border-green-500/50 bg-green-500/10',
  },
  PAUSED: { label: 'EN PAUSA', text: 'text-amber-300', dot: 'bg-amber-400', ping: false, ring: 'border-amber-500/50 bg-amber-500/10' },
  COMPLETED: { label: 'RUTA COMPLETADA', text: 'text-sky-300', dot: 'bg-sky-400', ping: false, ring: 'border-sky-500/50 bg-sky-500/10' },
};

/** Indicador de estado: punto verde pulsante cuando la simulación está activa. */
export function StatusPill({ status }: { status: SimulationStatus }) {
  const style = STATUS_STYLES[status];
  return (
    <span
      className={cn(
        'inline-flex items-center gap-2 rounded-full border px-3 py-1 text-[11px] font-bold tracking-wider',
        style.ring,
        style.text,
      )}
    >
      <span className="relative flex h-2 w-2">
        {style.ping ? <span className={cn('absolute inline-flex h-full w-full animate-ping rounded-full opacity-75', style.dot)} /> : null}
        <span className={cn('relative inline-flex h-2 w-2 rounded-full', style.dot)} />
      </span>
      {style.label}
    </span>
  );
}

interface TelemetryGridProps {
  state: SimulationState;
  fixedPoint: LocationPoint | null;
  accuracyMeters: number;
  speedUnit: SpeedUnit;
  loop: boolean;
}

/** Telemetría en tiempo real: coordenadas, velocidad, rumbo, precisión y progreso. */
export function TelemetryGrid({ state, fixedPoint, accuracyMeters, speedUnit, loop }: TelemetryGridProps) {
  const fix = state.currentFix;
  const coords = fix ?? (state.mode === 'POINT' ? fixedPoint : null);
  const isRoute = state.mode === 'ROUTE';
  const progress = state.totalMeters > 0 ? Math.min(state.traveledMeters / state.totalMeters, 1) : 0;

  const cells: { label: string; value: string; mono?: boolean }[] = [
    { label: 'Latitud', value: coords ? formatCoordinate(coords.latitude) : '—', mono: true },
    { label: 'Longitud', value: coords ? formatCoordinate(coords.longitude) : '—', mono: true },
    { label: 'Velocidad', value: fix ? formatSpeed(fix.speedMs, speedUnit) : '—' },
    { label: 'Rumbo', value: fix && isRoute ? formatBearing(fix.bearingDeg) : '—' },
    { label: 'Precisión', value: `±${accuracyMeters} m` },
    { label: 'Recorrido', value: isRoute ? `${formatDistance(state.traveledMeters)} / ${formatDistance(state.totalMeters)}` : 'Punto fijo' },
  ];

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-2">
        {cells.map((cell) => (
          <div key={cell.label} className="min-w-0 rounded-xl border border-zinc-800 bg-zinc-900/70 px-3 py-2">
            <p className="text-[10px] font-semibold uppercase tracking-wider text-zinc-500">{cell.label}</p>
            <p className={cn('truncate text-sm text-zinc-100', cell.mono && 'font-mono text-[13px]')}>{cell.value}</p>
          </div>
        ))}
      </div>
      {isRoute ? (
        <div>
          <div className="mb-1 flex items-center justify-between text-[11px] text-zinc-500">
            <span>Progreso{loop ? ' · bucle' : ''}</span>
            <span className="font-mono">
              {Math.round(progress * 100)}%{loop && state.lap > 0 ? ` · vuelta ${state.lap + 1}` : ''}
            </span>
          </div>
          <div className="h-1.5 overflow-hidden rounded-full bg-zinc-800" role="progressbar" aria-valuenow={Math.round(progress * 100)} aria-valuemin={0} aria-valuemax={100}>
            <div className="h-full rounded-full bg-green-500 transition-[width] duration-300" style={{ width: `${progress * 100}%` }} />
          </div>
        </div>
      ) : null}
    </div>
  );
}
