import { useState, type FormEvent } from 'react';
import type { LocationPoint } from '@/domain/types';
import { parseCoordinatePair } from '@/domain/validation';
import { Button, Field, INPUT_CLASS } from './ui';

interface CoordinateFormProps {
  initial: LocationPoint | null;
  submitLabel: string;
  onSubmit: (point: LocationPoint) => void;
}

/** Entrada manual de Latitud/Longitud con validación estricta (-90..90 / -180..180). */
export function CoordinateForm({ initial, submitLabel, onSubmit }: CoordinateFormProps) {
  const [lat, setLat] = useState(initial ? initial.latitude.toFixed(6) : '');
  const [lng, setLng] = useState(initial ? initial.longitude.toFixed(6) : '');
  const [latError, setLatError] = useState<string | null>(null);
  const [lngError, setLngError] = useState<string | null>(null);

  const handleSubmit = (event: FormEvent) => {
    event.preventDefault();
    const result = parseCoordinatePair(lat, lng);
    if (!result.ok) {
      setLatError(result.latitudeError);
      setLngError(result.longitudeError);
      return;
    }
    setLatError(null);
    setLngError(null);
    onSubmit(result.point);
  };

  return (
    <form onSubmit={handleSubmit} noValidate className="grid grid-cols-[1fr_1fr_auto] items-end gap-2">
      <Field label="Latitud" error={latError}>
        <input
          inputMode="decimal"
          value={lat}
          placeholder="-90 a 90"
          aria-invalid={latError ? true : undefined}
          onChange={(e) => {
            setLat(e.target.value);
            setLatError(null);
          }}
          className={INPUT_CLASS}
        />
      </Field>
      <Field label="Longitud" error={lngError}>
        <input
          inputMode="decimal"
          value={lng}
          placeholder="-180 a 180"
          aria-invalid={lngError ? true : undefined}
          onChange={(e) => {
            setLng(e.target.value);
            setLngError(null);
          }}
          className={INPUT_CLASS}
        />
      </Field>
      <Button type="submit" variant="primary" className="h-[42px] px-4">
        {submitLabel}
      </Button>
    </form>
  );
}
