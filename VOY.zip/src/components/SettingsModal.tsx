import { useState } from 'react';
import { Trash2 } from 'lucide-react';
import type { AppSettings, SpeedUnit } from '@/domain/types';
import { INTERVAL_RANGE_MS, parseNumberInRange } from '@/domain/validation';
import { cn } from '@/utils/cn';
import { AndroidGuide } from './AndroidGuide';
import { Button, Dialog, FOCUS_RING, INPUT_CLASS, Segmented } from './ui';

interface SettingsModalProps {
  open: boolean;
  onClose: () => void;
  settings: AppSettings;
  onChange: (patch: Partial<AppSettings>) => void;
  onResetAll: () => void;
}

const UNIT_OPTIONS: { value: SpeedUnit; label: string }[] = [
  { value: 'KMH', label: 'km/h' },
  { value: 'MS', label: 'm/s' },
];

const INTERVAL_PRESETS = [250, 500, 1000, 2000, 5000];

type Tab = 'SETTINGS' | 'ANDROID';

/** Ajustes de unidades e intervalo, privacidad y guía Android. */
export function SettingsModal({ open, onClose, settings, onChange, onResetAll }: SettingsModalProps) {
  const [tab, setTab] = useState<Tab>('SETTINGS');
  const [intervalDraft, setIntervalDraft] = useState<string | null>(null);
  const [intervalError, setIntervalError] = useState<string | null>(null);
  const [confirmReset, setConfirmReset] = useState(false);

  const applyInterval = () => {
    const result = parseNumberInRange(
      intervalDraft ?? String(settings.updateIntervalMs),
      INTERVAL_RANGE_MS.min,
      INTERVAL_RANGE_MS.max,
      'El intervalo',
      true,
    );
    if (!result.ok) {
      setIntervalError(result.error);
      return;
    }
    setIntervalError(null);
    setIntervalDraft(null);
    onChange({ updateIntervalMs: result.value });
  };

  return (
    <Dialog open={open} onClose={onClose} title="Ajustes y guía Android">
      <div role="tablist" className="mb-4 grid grid-cols-2 gap-1 rounded-xl border border-zinc-800 bg-zinc-900 p-1">
        {(
          [
            ['SETTINGS', 'Ajustes'],
            ['ANDROID', 'Guía Android'],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            role="tab"
            type="button"
            aria-selected={tab === id}
            onClick={() => setTab(id)}
            className={cn(
              'rounded-lg px-3 py-2 text-sm font-medium transition',
              FOCUS_RING,
              tab === id ? 'bg-green-500 text-zinc-950' : 'text-zinc-400 hover:text-zinc-100',
            )}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === 'ANDROID' ? (
        <AndroidGuide />
      ) : (
        <div className="space-y-6">
          <section className="space-y-2">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-zinc-400">Unidades de velocidad</h3>
            <Segmented
              options={UNIT_OPTIONS}
              value={settings.speedUnit}
              onChange={(speedUnit) => onChange({ speedUnit })}
              ariaLabel="Unidades de velocidad"
            />
            <p className="text-xs text-zinc-500">Afecta a la telemetría. La entrada de velocidad de ruta siempre es en km/h.</p>
          </section>

          <section className="space-y-2">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-zinc-400">Intervalo de actualización</h3>
            <div className="flex flex-wrap gap-2">
              {INTERVAL_PRESETS.map((ms) => (
                <button
                  key={ms}
                  type="button"
                  aria-pressed={settings.updateIntervalMs === ms}
                  onClick={() => {
                    setIntervalDraft(null);
                    setIntervalError(null);
                    onChange({ updateIntervalMs: ms });
                  }}
                  className={cn(
                    'rounded-lg border px-3 py-1.5 font-mono text-xs transition',
                    FOCUS_RING,
                    settings.updateIntervalMs === ms
                      ? 'border-green-500 bg-green-500/15 text-green-200'
                      : 'border-zinc-700 text-zinc-300 hover:border-zinc-600',
                  )}
                >
                  {ms} ms
                </button>
              ))}
            </div>
            <form
              noValidate
              onSubmit={(e) => {
                e.preventDefault();
                applyInterval();
              }}
              className="flex gap-2"
            >
              <input
                inputMode="numeric"
                aria-label="Intervalo personalizado en milisegundos"
                value={intervalDraft ?? String(settings.updateIntervalMs)}
                onChange={(e) => {
                  setIntervalDraft(e.target.value);
                  setIntervalError(null);
                }}
                aria-invalid={intervalError ? true : undefined}
                className={cn(INPUT_CLASS, 'font-mono')}
              />
              <Button type="submit" variant="secondary" className="shrink-0">
                Aplicar
              </Button>
            </form>
            {intervalError ? <p className="text-xs text-red-400">{intervalError}</p> : null}
            <p className="text-xs text-zinc-500">
              Entre {INTERVAL_RANGE_MS.min} y {INTERVAL_RANGE_MS.max} ms. Menor intervalo = movimiento más fluido.
            </p>
          </section>

          <section className="space-y-2 rounded-xl border border-zinc-800 bg-zinc-900/60 p-4">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-zinc-400">Privacidad</h3>
            <ul className="space-y-1 text-sm text-zinc-300">
              <li>• 100% libre de publicidad, banners y pop-ups.</li>
              <li>• Sin compras integradas ni cuentas de usuario.</li>
              <li>• Favoritos, historial y ajustes solo en este dispositivo.</li>
            </ul>
            <div className="pt-2">
              {confirmReset ? (
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-xs text-red-300">¿Borrar favoritos, historial y ajustes?</span>
                  <Button variant="danger" className="px-3 py-1.5 text-xs" onClick={() => { onResetAll(); setConfirmReset(false); }}>
                    Sí, borrar
                  </Button>
                  <Button variant="ghost" className="px-3 py-1.5 text-xs" onClick={() => setConfirmReset(false)}>
                    Cancelar
                  </Button>
                </div>
              ) : (
                <Button variant="danger" onClick={() => setConfirmReset(true)}>
                  <Trash2 className="h-4 w-4" aria-hidden="true" />
                  Borrar datos locales
                </Button>
              )}
            </div>
          </section>
        </div>
      )}
    </Dialog>
  );
}
