import { Radio } from 'lucide-react';
import type { LocationFix, SpeedUnit } from '@/domain/types';
import { formatCoordinate, formatSpeed } from '@/domain/geo';
import { VoyLogo } from './Logo';
import { FOCUS_RING } from './ui';
import { cn } from '@/utils/cn';

interface AndroidNotificationProps {
  visible: boolean;
  paused: boolean;
  fix: LocationFix | null;
  speedUnit: SpeedUnit;
  onStop: () => void;
}

/**
 * Simulación visual de la notificación persistente de Android (ForegroundService
 * con foregroundServiceType="location") mientras la ubicación simulada está activa.
 */
export function AndroidNotification({ visible, paused, fix, speedUnit, onStop }: AndroidNotificationProps) {
  if (!visible) return null;

  const coords = fix
    ? `${formatCoordinate(fix.latitude)}, ${formatCoordinate(fix.longitude)}`
    : 'Obteniendo posición…';

  return (
    <div
      role="status"
      aria-live="polite"
      className="pointer-events-auto flex items-center gap-3 rounded-2xl border border-zinc-700/70 bg-zinc-900/95 px-3 py-2.5 shadow-xl backdrop-blur animate-[voy-slide_.3s_ease-out]"
    >
      <div className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-green-500/15 ring-1 ring-green-500/30">
        <VoyLogo className="h-6 w-6" />
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-wider text-zinc-500">
          <span className="font-semibold text-zinc-300">VOY</span>
          <span>·</span>
          <span>Ubicación simulada</span>
          <Radio className={cn('ml-auto h-3 w-3', paused ? 'text-amber-400' : 'text-green-400')} aria-hidden="true" />
        </div>
        <p className="truncate text-sm font-semibold text-white">
          {paused ? 'En pausa · ubicación congelada' : 'Ubicación simulada activa'}
        </p>
        <p className="truncate font-mono text-[11px] text-zinc-400">
          {coords}
          {fix ? ` · ${formatSpeed(fix.speedMs, speedUnit)}` : ''}
        </p>
      </div>
      <button
        type="button"
        onClick={onStop}
        className={cn('shrink-0 rounded-lg px-3 py-1.5 text-xs font-semibold text-red-300 hover:bg-red-500/10', FOCUS_RING)}
      >
        Detener
      </button>
    </div>
  );
}
