import { useState } from 'react';
import { ChevronDown, History, Settings, Star } from 'lucide-react';
import type { LocationPoint, SimulationMode } from '@/domain/types';
import type { PlaceResult } from '@/services/nominatim';
import type { PlaceSearch } from '@/hooks/usePlaceSearch';
import { cn } from '@/utils/cn';
import { VoyLogo } from './Logo';
import { SearchBox } from './SearchBox';
import { CoordinateForm } from './CoordinateForm';
import { FOCUS_RING, IconButton } from './ui';

interface TopPanelProps {
  mode: SimulationMode;
  fixedPoint: LocationPoint | null;
  search: PlaceSearch;
  onPickPlace: (place: PlaceResult) => void;
  onSubmitCoordinates: (point: LocationPoint) => void;
  onOpenLibrary: () => void;
  onOpenHistory: () => void;
  onOpenSettings: () => void;
}

/** Panel superior flotante: marca, acciones, buscador y entrada de coordenadas. */
export function TopPanel({
  mode,
  fixedPoint,
  search,
  onPickPlace,
  onSubmitCoordinates,
  onOpenLibrary,
  onOpenHistory,
  onOpenSettings,
}: TopPanelProps) {
  const [coordsOpen, setCoordsOpen] = useState(false);
  const pointKey = fixedPoint ? `${fixedPoint.latitude}_${fixedPoint.longitude}` : 'none';

  return (
    <header className="pointer-events-auto rounded-2xl border border-zinc-800/80 bg-zinc-950/90 p-2.5 shadow-2xl shadow-black/60 backdrop-blur-md">
      <div className="flex items-center gap-2">
        <VoyLogo className="h-9 w-9 shrink-0 drop-shadow-[0_0_8px_rgba(34,197,94,0.35)]" />
        <div className="min-w-0 flex-1 leading-tight">
          <h1 className="text-lg font-black tracking-[0.25em] text-white">VOY</h1>
          <p className="truncate text-[10px] font-medium uppercase tracking-widest text-zinc-500">
            Simulador de ubicación
          </p>
        </div>
        <IconButton label="Favoritos y rutas" onClick={onOpenLibrary}>
          <Star className="h-[18px] w-[18px]" />
        </IconButton>
        <IconButton label="Historial" onClick={onOpenHistory}>
          <History className="h-[18px] w-[18px]" />
        </IconButton>
        <IconButton label="Ajustes y guía Android" onClick={onOpenSettings}>
          <Settings className="h-[18px] w-[18px]" />
        </IconButton>
      </div>

      <div className="mt-2.5">
        <SearchBox search={search} onPick={onPickPlace} />
      </div>

      <button
        type="button"
        aria-expanded={coordsOpen}
        onClick={() => setCoordsOpen((open) => !open)}
        className={cn(
          'mt-2 flex w-full items-center justify-between rounded-lg px-1 py-1 text-xs font-medium text-zinc-400 hover:text-zinc-100',
          FOCUS_RING,
        )}
      >
        <span>Coordenadas manuales (lat / lng)</span>
        <ChevronDown className={cn('h-4 w-4 transition-transform', coordsOpen && 'rotate-180')} />
      </button>

      {coordsOpen ? (
        <div className="mt-2">
          <CoordinateForm
            key={`${mode}-${pointKey}`}
            initial={mode === 'POINT' ? fixedPoint : null}
            submitLabel={mode === 'POINT' ? 'Fijar' : 'Añadir'}
            onSubmit={onSubmitCoordinates}
          />
          <p className="mt-1.5 text-[11px] text-zinc-600">
            {mode === 'POINT'
              ? 'Latitud −90…90 · Longitud −180…180. Fija el punto de simulación.'
              : 'En modo Ruta, la coordenada se añade como nuevo punto de la ruta.'}
          </p>
        </div>
      ) : null}
    </header>
  );
}
