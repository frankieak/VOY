import * as L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { forwardRef, useEffect, useImperativeHandle, useRef } from 'react';
import type { LocationFix, LocationPoint, SimulationMode } from '@/domain/types';

/*
 * CAPA DE MAPA (Leaflet + OpenStreetMap, sin API key).
 * Solo presentación: recibe datos y emite eventos. Equivalente Kotlin:
 * un composable que envuelve el mapa (osmdroid / Google Maps Compose) y
 * emite eventos al ViewModel.
 */

export interface MapHandle {
  flyTo: (point: LocationPoint, zoom?: number) => void;
  fitTo: (points: LocationPoint[]) => void;
  zoomIn: () => void;
  zoomOut: () => void;
}

export interface MapViewProps {
  mode: SimulationMode;
  fixedPoint: LocationPoint | null;
  waypoints: LocationPoint[];
  fix: LocationFix | null;
  accuracyMeters: number;
  follow: boolean;
  onMapClick: (point: LocationPoint) => void;
  onFixedPointChange: (point: LocationPoint) => void;
  onWaypointChange: (index: number, point: LocationPoint) => void;
  onUserPan: () => void;
}

const DEFAULT_CENTER: LocationPoint = { latitude: 40.4168, longitude: -3.7038 };
const toLatLng = (p: LocationPoint): L.LatLngExpression => [p.latitude, p.longitude];

const PIN_ICON = L.divIcon({
  className: 'voy-marker',
  html:
    '<svg width="36" height="46" viewBox="0 0 48 60" aria-hidden="true" style="filter:drop-shadow(0 4px 6px rgba(0,0,0,.5))">' +
    '<path d="M24 58C24 58 6 38.5 6 22.5a18 18 0 0 1 36 0C42 38.5 24 58 24 58z" fill="#16A34A" stroke="#22C55E" stroke-width="2"/>' +
    '<circle cx="24" cy="22.5" r="7" fill="#052e16"/><circle cx="24" cy="22.5" r="3" fill="#4ADE80"/></svg>',
  iconSize: [36, 46],
  iconAnchor: [18, 46],
});

const FIX_ICON = L.divIcon({
  className: 'voy-marker',
  html: '<div class="voy-fix"><span class="voy-fix-ring"></span><span class="voy-fix-dot"></span></div>',
  iconSize: [24, 24],
  iconAnchor: [12, 12],
});

const waypointIcon = (n: number) =>
  L.divIcon({
    className: 'voy-marker',
    html: `<div class="voy-wp">${n}</div>`,
    iconSize: [28, 28],
    iconAnchor: [14, 14],
  });

export const MapView = forwardRef<MapHandle, MapViewProps>(function MapView(props, ref) {
  const { mode, fixedPoint, waypoints, fix, accuracyMeters, follow } = props;
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);
  const layerRef = useRef<L.LayerGroup | null>(null);
  // Los handlers de Leaflet se registran una sola vez: leen siempre las props actuales.
  const propsRef = useRef(props);

  useEffect(() => {
    propsRef.current = props;
  });

  useImperativeHandle(
    ref,
    () => ({
      flyTo: (point, zoom) => {
        const map = mapRef.current;
        if (!map) return;
        map.flyTo(toLatLng(point), zoom ?? Math.max(map.getZoom(), 15), { duration: 0.8 });
      },
      fitTo: (points) => {
        const map = mapRef.current;
        if (!map || points.length === 0) return;
        map.fitBounds(L.latLngBounds(points.map(toLatLng)), { padding: [48, 48], maxZoom: 17 });
      },
      zoomIn: () => mapRef.current?.zoomIn(),
      zoomOut: () => mapRef.current?.zoomOut(),
    }),
    [],
  );

  // Ciclo de vida del mapa: creación y destrucción limpia (StrictMode-safe).
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;

    const initial = propsRef.current.fixedPoint ?? DEFAULT_CENTER;
    const map = L.map(el, {
      zoomControl: false,
      attributionControl: false,
      minZoom: 2,
      maxZoom: 19,
      worldCopyJump: true,
    }).setView(toLatLng(initial), propsRef.current.fixedPoint ? 15 : 13);

    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; OpenStreetMap contributors',
    }).addTo(map);

    layerRef.current = L.layerGroup().addTo(map);

    map.on('click', (event: L.LeafletMouseEvent) => {
      propsRef.current.onMapClick({ latitude: event.latlng.lat, longitude: event.latlng.lng });
    });
    map.on('dragstart', () => propsRef.current.onUserPan());

    const onResize = () => map.invalidateSize();
    window.addEventListener('resize', onResize);
    mapRef.current = map;

    return () => {
      window.removeEventListener('resize', onResize);
      map.remove();
      mapRef.current = null;
      layerRef.current = null;
    };
  }, []);

  // Capa de overlays: marcadores, ruta, precisión y posición simulada.
  useEffect(() => {
    const layer = layerRef.current;
    if (!layer) return;
    layer.clearLayers();

    if (mode === 'POINT' && fixedPoint) {
      const marker = L.marker(toLatLng(fixedPoint), {
        icon: PIN_ICON,
        draggable: true,
        zIndexOffset: 500,
        title: 'Punto fijo (arrastrable)',
      });
      marker.on('dragend', () => {
        const ll = marker.getLatLng();
        propsRef.current.onFixedPointChange({ latitude: ll.lat, longitude: ll.lng });
      });
      marker.addTo(layer);
    }

    if (mode === 'ROUTE') {
      if (waypoints.length > 1) {
        L.polyline(waypoints.map(toLatLng), {
          color: '#22C55E',
          weight: 4,
          opacity: 0.95,
          dashArray: '10 8',
          interactive: false,
        }).addTo(layer);
      }
      waypoints.forEach((wp, index) => {
        const marker = L.marker(toLatLng(wp), {
          icon: waypointIcon(index + 1),
          draggable: true,
          zIndexOffset: 300,
          title: `Punto ${index + 1} (arrastrable)`,
        });
        marker.on('dragend', () => {
          const ll = marker.getLatLng();
          propsRef.current.onWaypointChange(index, { latitude: ll.lat, longitude: ll.lng });
        });
        marker.addTo(layer);
      });
    }

    if (fix) {
      L.circle(toLatLng(fix), {
        radius: Math.max(accuracyMeters, 1),
        color: '#22C55E',
        weight: 1,
        fillColor: '#22C55E',
        fillOpacity: 0.12,
        interactive: false,
      }).addTo(layer);
      L.marker(toLatLng(fix), { icon: FIX_ICON, interactive: false, keyboard: false, zIndexOffset: 1000 }).addTo(layer);
    }
  }, [mode, fixedPoint, waypoints, fix, accuracyMeters]);

  // Seguimiento: el mapa acompaña la posición simulada mientras "follow" esté activo.
  useEffect(() => {
    if (!follow || !fix) return;
    mapRef.current?.panTo(toLatLng(fix), { animate: true, duration: 0.6 });
  }, [follow, fix]);

  return <div ref={containerRef} className="voy-map absolute inset-0 z-0" />;
});
